# J.A.R.V.I.S — Gemini API Edition

Windows için hazırlanmış, tamamen Gemini API üzerinden çalışan profesyonel masaüstü asistanı.

## Özellikler
- Gemini API tabanlı sohbet ve araç kullanımı
- Görsel / müzik / video üretimi
- Dosya, klasör ve çalışma alanı yönetimi
- Ekran analizi ve görsel içerik okuma
- Güvenli klavye ve mouse otomasyonu
- Ayrıntılı yerel loglama
- Geliştirici araçları ve kod üretimi desteği
- 4 GB RAM sistemler için düşük kaynak tüketen varsayılan yapı

## Kurulum
1. Python 3.11+ kurun ve `Add Python to PATH` seçeneğini açın.
2. Gerekirse GitHub arşivini çıkartın.
3. `setup_windows.ps1` dosyasını PowerShell ile çalıştırın.
4. Gemini API anahtarınızı girin.
5. Kullanmak istediğiniz modelleri seçin.

## Çalıştırma
```powershell
.\.venv\Scripts\python.exe main.py
```

## Önerilen varsayılanlar
- Sohbet modeli: `gemini-3.1-flash-lite-preview`
- Görsel model: `gemini-3.1-flash-preview`
- Görsel üretim: `imagen-4.0-generate-001`
- Müzik üretim: `lyria-3-clip-preview`
- Video üretim: `veo-3.1-lite-generate-preview`

## Not
Bu sürüm yerel LLM kullanmaz; tüm yapay zekâ etkileşimi Gemini API üzerinden yürür.
