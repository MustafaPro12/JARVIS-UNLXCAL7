$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "╔════════════════════════════════════════════╗"
Write-Host "║     J.A.R.V.I.S  Gemini API Kurulumu      ║"
Write-Host "╚════════════════════════════════════════════╝"
Write-Host ""

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python bulunamadı. Python 3.11+ kurup tekrar deneyin."
    exit 1
}

python --version

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt

Write-Host ""
Write-Host "Gemini model seçimi"
Write-Host "1) gemini-3.1-flash-lite-preview (en hafif / düşük RAM için)"
Write-Host "2) gemini-3.1-flash-preview"
Write-Host "3) gemini-3.1-pro-preview"
$textChoice = Read-Host "Ana sohbet modeli numarası [1]"
if ([string]::IsNullOrWhiteSpace($textChoice)) { $textChoice = "1" }

$textModel = switch ($textChoice.Trim()) {
    "2" { "gemini-3.1-flash-preview" }
    "3" { "gemini-3.1-pro-preview" }
    default { "gemini-3.1-flash-lite-preview" }
}

Write-Host ""
Write-Host "Görsel analiz modeli"
Write-Host "1) gemini-3.1-flash-preview"
Write-Host "2) gemini-3.1-flash-lite-preview"
$visionChoice = Read-Host "Vision model numarası [1]"
if ([string]::IsNullOrWhiteSpace($visionChoice)) { $visionChoice = "1" }

$visionModel = switch ($visionChoice.Trim()) {
    "2" { "gemini-3.1-flash-lite-preview" }
    default { "gemini-3.1-flash-preview" }
}

Write-Host ""
Write-Host "Medya üretim modelleri (opsiyonel ama hazır)"
$imageModel = Read-Host "Görsel model [imagen-4.0-generate-001]"
if ([string]::IsNullOrWhiteSpace($imageModel)) { $imageModel = "imagen-4.0-generate-001" }
$musicModel = Read-Host "Müzik model [lyria-3-clip-preview]"
if ([string]::IsNullOrWhiteSpace($musicModel)) { $musicModel = "lyria-3-clip-preview" }
$videoModel = Read-Host "Video model [veo-3.1-lite-generate-preview]"
if ([string]::IsNullOrWhiteSpace($videoModel)) { $videoModel = "veo-3.1-lite-generate-preview" }

$generatedDir = Read-Host "Üretilen medya klasörü [boşsa otomatik]"
if ([string]::IsNullOrWhiteSpace($generatedDir)) { $generatedDir = "" }

$enableGui = Read-Host "Fare/klavye kontrolü etkin olsun mu? (E/H) [H]"
if ([string]::IsNullOrWhiteSpace($enableGui)) { $enableGui = "H" }

$geminiKey = Read-Host "Gemini API Key"

$configDir = Join-Path (Get-Location) "config"
New-Item -ItemType Directory -Force -Path $configDir | Out-Null
$configPath = Join-Path $configDir "api_keys.json"
$config = @{
    voice = "Charon"
    gemini_api_key = $geminiKey
    model_provider = "gemini"
    gemini_live_model = "gemini-3.1-flash-live-preview"
    gemini_text_model = $textModel
    gemini_vision_model = $visionModel
    gemini_image_model = $imageModel
    gemini_music_model = $musicModel
    gemini_video_model = $videoModel
    local_only = $false
    logging_enabled = $true
    workspace_roots = @("desktop","downloads")
    image_backend = "gemini"
    image_model_id = $imageModel
    music_backend = "gemini"
    music_model_id = $musicModel
    video_backend = "gemini"
    video_model_id = $videoModel
    generated_media_dir = $generatedDir
    gui_control_enabled = ($enableGui.Trim().ToUpper() -eq "E")
    control_requires_confirmation = $true
    allow_file_actions = $true
    allow_model_generation = $true
    allow_screen_analysis = $true
    memory_policy = "local_only"
    max_generation_size = 1024
    max_music_seconds = 30
    max_video_seconds = 8
    developer_mode = $true
    log_retention_days = 30
}
$config | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $configPath

if (Test-Path "requirements_ai.txt") {
    .\.venv\Scripts\python.exe -m pip install -r requirements_ai.txt
}

if (Test-Path "requirements_optional.txt") {
    .\.venv\Scripts\python.exe -m pip install -r requirements_optional.txt
}

Write-Host ""
Write-Host "Kurulum tamamlandı."
Write-Host "Jarvis'i başlatmak için: .\.venv\Scripts\python.exe main.py"
