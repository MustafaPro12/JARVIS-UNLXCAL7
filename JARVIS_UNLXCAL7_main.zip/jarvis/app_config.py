# Alp Ünlü tarafından yapılmıştır — @alppunlu
from __future__ import annotations

import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_DIR = BASE_DIR / "config"
CONFIG_PATH = CONFIG_DIR / "api_keys.json"

DEFAULT_CONFIG = {
    "voice": "Charon",
    "gemini_api_key": "",
    "model_provider": "gemini",
    "gemini_live_model": "gemini-3.1-flash-live-preview",
    "gemini_text_model": "gemini-3.1-flash-lite-preview",
    "gemini_vision_model": "gemini-3.1-flash-preview",
    "gemini_image_model": "imagen-4.0-generate-001",
    "gemini_video_model": "veo-3.1-lite-generate-preview",
    "gemini_music_model": "lyria-3-clip-preview",
    "local_only": False,
    "logging_enabled": True,
    "workspace_roots": ["desktop", "downloads"],
    "developer_mode": True,
    "log_retention_days": 30,
    "preferred_text_models": ["gemini-3.1-flash-lite-preview", "gemini-3.1-flash-preview", "gemini-3.1-pro-preview"],
    "preferred_vision_models": ["gemini-3.1-flash-preview", "gemini-3.1-flash-lite-preview"],

    "image_backend": "gemini",
    "image_model_id": "imagen-4.0-generate-001",
    "music_backend": "gemini",
    "music_model_id": "lyria-3-clip-preview",
    "video_backend": "gemini",
    "video_model_id": "veo-3.1-lite-generate-preview",
    "generated_media_dir": "",
    "gui_control_enabled": False,
    "control_requires_confirmation": True,
    "allow_file_actions": True,
    "allow_model_generation": True,
    "allow_screen_analysis": True,
    "memory_policy": "local_only",
    "max_generation_size": 1024,
    "max_music_seconds": 30,
    "max_video_seconds": 8,
    "ui_confirm_dangerous_actions": True,
    "log_to_console": False,
}



def load_app_config() -> dict:
    config = dict(DEFAULT_CONFIG)
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            config.update(raw)
    except Exception:
        pass
    return config


def save_app_config(updates: dict) -> dict:
    config = load_app_config()
    for key, value in (updates or {}).items():
        if value is None:
            continue
        config[key] = value
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=4, ensure_ascii=False), encoding="utf-8")
    return config


def get_app_config_value(key: str, default=None):
    return load_app_config().get(key, default)


def has_gemini_api_key() -> bool:
    try:
        config = load_app_config()
        if str(config.get("gemini_api_key", "") or "").strip():
            return True
    except Exception:
        pass
    return bool(str(__import__("os").environ.get("GEMINI_API_KEY", "") or "").strip())


def update_app_settings(updates: dict) -> dict:
    return save_app_config(updates)

