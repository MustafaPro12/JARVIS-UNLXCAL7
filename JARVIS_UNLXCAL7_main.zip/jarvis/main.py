#!/usr/bin/env python3
"""
JARVIS Windows — Gercek zamanli sesli yardimci cekirdegi
Alp Ünlü tarafından yapılmıştır — @alppunlu
Windows ortamina uyarlanmis calisma akisi
"""

import asyncio
import datetime
import json
import threading
import traceback
import os
import re
from pathlib import Path
from types import SimpleNamespace

try:
    import pyaudio  # type: ignore[reportMissingModuleSource]
except Exception:
    pyaudio = None  # type: ignore[assignment]

try:
    from google import genai  # type: ignore[reportMissingImports]
    from google.genai import types  # type: ignore[reportMissingImports]
except Exception:
    genai = None  # type: ignore[assignment]
    types = None  # type: ignore[assignment]

from app_config import get_app_config_value, save_app_config, load_app_config
from ui import JarvisUI
from memory.memory_manager import load_memory, update_memory, save_memory_entry, delete_memory, search_memory, list_memory, format_memory_for_prompt
from actions.open_app import open_app
from actions.sys_info  import sys_info
from actions.calendar import get_calendar_events, add_calendar_event, delete_calendar_event
from actions.reminders import get_reminders, add_reminder
from actions.browser   import browser_control
from actions.shell     import shell_run
from actions.whatsapp  import send_whatsapp_message, save_whatsapp_contact
from actions.clipboard import get_clipboard_text, set_clipboard_text
from actions.file_tools import open_path, search_files, open_folder_shortcuts
from actions.workspace_tools import (
    create_workspace_folder,
    create_workspace_file,
    update_workspace_file,
    append_workspace_file,
    read_workspace_file,
    list_workspace_items,
    open_workspace_item,
    delete_workspace_item,
    rename_workspace_item,
    copy_workspace_item,
)
from actions.windows_utils import open_settings, show_desktop, lock_screen, open_folder
from actions.media     import play_media
from actions.weather   import get_weather_summary
from actions.screen_vision import analyze_screen
from actions.youtube_stats import get_youtube_channel_report
from actions.tts import speak_text
from actions.local_llm import gemini_available, gemini_chat, extract_json_object, gemini_list_models
from actions.file_inspector import analyze_file, analyze_image, analyze_folder
from actions.audit_log import start_session, log_conversation, log_tool_call, log_system, log_error
from actions.app_settings import list_app_settings, update_app_settings
from actions.gui_control import move_mouse, click_mouse, scroll_mouse, drag_mouse, press_keys, keyboard_hotkey, type_text, focus_window, emergency_stop
from actions.generative_media import list_generation_config, generate_image, generate_music, generate_video, generated_media_help

# ── Paths ───────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).resolve().parent
PROMPT_PATH     = BASE_DIR / "core" / "prompt.txt"


CONTROL_TOKEN_RE = re.compile(r"<ctrl\d+>", re.IGNORECASE)

# ── Model ───────────────────────────────────────────────────────────────────
LIVE_MODEL = "gemini-3.1-flash-live-preview"

# ── Audio ───────────────────────────────────────────────────────────────────
FORMAT           = getattr(pyaudio, "paInt16", None) if pyaudio else None
CHANNELS         = 1
SEND_SAMPLE_RATE = 16000
RECV_SAMPLE_RATE = 24000
CHUNK_SIZE       = 1024
pya              = pyaudio.PyAudio() if pyaudio else None
AUDIO_AVAILABLE  = pya is not None and FORMAT is not None

# ── Tool tanımları ──────────────────────────────────────────────────────────
TOOL_DECLARATIONS = [
    {
        "name": "open_app",
        "description": "Windows'ta herhangi bir uygulamayı açar. Spotify, Chrome, Komut İstemi, Dosya Gezgini, VS Code vb.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "app_name": {
                    "type": "STRING",
                    "description": "Uygulama adı (örn. 'Spotify', 'Edge', 'Terminal')"
                }
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "sys_info",
        "description": "Sistem bilgisi alır: pil durumu, CPU, RAM, disk, saat, tarih, ağ bağlantısı.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "battery | cpu | ram | disk | time | date | network | all"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_weather",
        "description": (
            "Anlik hava durumunu ozetler. Varsayilan konum Istanbul'dur. "
            "Kullanici hava durumunu, sicakligi veya yagmur durumunu sordugunda kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "location": {
                    "type": "STRING",
                    "description": "Sehir veya konum. Bos birakilirsa Istanbul kullanilir."
                }
            }
        }
    },
    {
        "name": "get_calendar_events",
        "description": (
            "Yerel hafızada saklanan takvim kayıtlarını okur. "
            "Bugün, yarın, sıradaki etkinlik veya yaklaşan ajandayı özetler. "
            "Kullanıcı toplantı, takvim, ajanda, etkinlik veya günlük programını sorduğunda kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": (
                        "today | tomorrow | next | agenda | week veya dogal dilde "
                        "'onumuzdeki 30 gun', '2 hafta', 'bu ay', 'gelecek ay'"
                    )
                },
                "limit": {
                    "type": "NUMBER",
                    "description": "Maksimum etkinlik sayisi"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "add_calendar_event",
        "description": (
            "Yerel hafızadaki takvime yeni etkinlik ekler. "
            "Kullanıcı toplantı, randevu, takvime ekleme veya etkinlik oluşturma isterse kullan. "
            "Başlangıç tarihini gerçek tarih/saat olarak ver; bitiş verilmezse varsayılan süre kullanılır."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Etkinlik basligi. Ornek: 'Disci Randevusu'"
                },
                "start_iso": {
                    "type": "STRING",
                    "description": "Baslangic tarih/saat. ISO veya yyyy-MM-dd HH:mm formatinda."
                },
                "end_iso": {
                    "type": "STRING",
                    "description": "Bitis tarih/saat. Opsiyonel."
                },
                "location": {
                    "type": "STRING",
                    "description": "Etkinlik konumu. Opsiyonel."
                },
                "notes": {
                    "type": "STRING",
                    "description": "Etkinlik notlari. Opsiyonel."
                },
                "calendar_name": {
                    "type": "STRING",
                    "description": "Eklenecek takvim adi. Opsiyonel."
                },
                "all_day": {
                    "type": "BOOLEAN",
                    "description": "true ise tum gun etkinligi olusturur."
                }
            },
            "required": ["title", "start_iso"]
        }
    },
    {
        "name": "delete_calendar_event",
        "description": (
            "Yerel hafızadaki takvim kaydını siler. "
            "Kullanıcı bir toplantıyı, randevuyu veya etkinliği silmek istediğinde kullan. "
            "Aynı ada birden fazla etkinlik varsa doğru kaydı bulmak için başlangıç tarihini gerçek tarih/saat olarak ver."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Silinecek etkinlik basligi. Ornek: 'Disci Randevusu'"
                },
                "start_iso": {
                    "type": "STRING",
                    "description": "Opsiyonel tarih/saat. Ayni isimli birden fazla etkinligi ayirt etmek icin kullan."
                },
                "calendar_name": {
                    "type": "STRING",
                    "description": "Opsiyonel takvim adi"
                },
                "delete_all_matches": {
                    "type": "BOOLEAN",
                    "description": "true ise eslesen tum etkinlikleri siler"
                }
            },
            "required": ["title"]
        }
    },
    {
        "name": "get_reminders",
        "description": (
            "Yerel hafızada saklanan hatırlatıcıları okur. "
            "Bugünkü, yaklaşan, geciken veya tüm açık hatırlatıcıları özetler. "
            "Kullanıcı hatırlatma, anımsatıcı, reminder veya yapılacaklar listesini sorduğunda kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "today | upcoming | overdue | all | next"
                },
                "limit": {
                    "type": "NUMBER",
                    "description": "Maksimum animsatici sayisi"
                },
                "list_name": {
                    "type": "STRING",
                    "description": "Istenirse belirli bir animsatici listesi adi"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "add_reminder",
        "description": (
            "Yerel hafızaya yeni bir hatırlatıcı ekler. "
            "Kullanıcı 'hatırlat', 'anımsatıcı ekle', 'reminder kur' dediğinde kullan. "
            "Göreli zaman ifadelerini bugünkü tarih bağlamına göre due_iso alanına ISO formatında çevir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Animsatici basligi"
                },
                "due_iso": {
                    "type": "STRING",
                    "description": "Opsiyonel tarih/saat. Ornek: 2026-04-13T09:00 veya tum gun icin 2026-04-13"
                },
                "notes": {
                    "type": "STRING",
                    "description": "Opsiyonel not"
                },
                "list_name": {
                    "type": "STRING",
                    "description": "Opsiyonel animsatici listesi"
                },
                "priority": {
                    "type": "STRING",
                    "description": "low | medium | high"
                },
                "all_day": {
                    "type": "BOOLEAN",
                    "description": "Tum gun animsatici ise true"
                }
            },
            "required": ["title"]
        }
    },
    {
        "name": "browser_control",
        "description": "Tarayıcıda URL açar, Google'da arama yapar veya YouTube'da ilk sonucu doğrudan oynatır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "open_url | search | play_youtube"},
                "url":    {"type": "STRING", "description": "Açılacak URL (open_url için)"},
                "query":  {"type": "STRING", "description": "Arama sorgusu (search veya play_youtube için)"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "shell_run",
        "description": "Güvenli terminal komutu çalıştırır. Dosya işlemleri ve sistem yönetimi.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "command": {
                    "type": "STRING",
                    "description": "Çalıştırılacak bash komutu"
                }
            },
            "required": ["command"]
        }
    },
    {
        "name": "play_media",
        "description": (
            "YouTube, Spotify veya Apple Music/Music uygulamasında şarkı, müzik veya video açar. "
            "Kullanıcı belirli bir platform söylerse onu kullan. "
            "Belirtmezse uygun olanı dene. "
            "Kullanıcı 'çal', 'oynat', 'aç' diyorsa autoplay=true kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "Şarkı, sanatçı, albüm veya video arama ifadesi"
                },
                "provider": {
                    "type": "STRING",
                    "description": "auto | youtube | spotify | apple_music"
                },
                "autoplay": {
                    "type": "BOOLEAN",
                    "description": "true ise mümkünse doğrudan oynatır"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_youtube_channel_report",
        "description": (
            "YouTube kanalinin public istatistiklerini ve son videolarin performansini raporlar. "
            "Kullanici kanal istatistiklerini, abone sayisini, son videolarini, buyume hizini "
            "veya YouTube analizini sordugunda kullan. Bu arac Studio yerine public YouTube Data API verisini kullanir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": (
                        "Dogal dilde analiz istegi. Ornek: "
                        "'YouTube istatistiklerim nasil', 'son videolarimi analiz et', "
                        "'kanal buyumemi ozetle'"
                    )
                },
                "handle": {
                    "type": "STRING",
                    "description": (
                        "Opsiyonel kanal handle'i, kanal linki veya kanal ID'si. "
                        "Bos birakilirsa ayarlardaki youtube_channel_handle kullanilir."
                    )
                },
                "video_limit": {
                    "type": "NUMBER",
                    "description": "Analize dahil edilecek son video sayisi. Varsayilan 6."
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "analyze_screen",
        "description": (
            "Aktif pencerenin ekran görüntüsünü alıp yerel vision model ile analiz eder. "
            "Kullanici ekranda ne oldugunu, bir hatayi, gorunen metni, butonlari veya pencere icerigini sordugunda kullan. "
            "Bu surum yalnizca aktif pencereyi destekler."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "Kullanicinin ekranla ilgili sorusu. Ornek: 'Bu hatayi oku', 'Ekranda ne var?'"
                },
                "target": {
                    "type": "STRING",
                    "description": "Su an sadece active_window desteklenir."
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "save_memory",
        "description": "Kullanıcı hakkında önemli bilgiyi kalıcı belleğe kaydeder. İsim, tercihler, projeler, notlar ve tekrar kullanılacak detaylar için kullan.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {
                    "type": "STRING",
                    "description": "identity | preferences | projects | notes | contacts | tasks"
                },
                "key":   {"type": "STRING", "description": "Kısa anahtar (örn. 'name')"},
                "value": {"type": "STRING", "description": "Kaydedilecek değer"},
                "tags": {
                    "type": "STRING",
                    "description": "Virgülle ayrılmış etiketler; örn. 'windows,ui,tercih'"
                },
                "importance": {
                    "type": "STRING",
                    "description": "low | normal | high"
                }
            },
            "required": ["category", "key", "value"]
        }
    },
    {
        "name": "delete_memory",
        "description": (
            "Kalici hafizadaki bir kaydi siler. "
            "Kullanici 'bunu hafizandan kaldir', 'unut', 'sil' gibi bir sey derse kullan. "
            "Mumkunse category ve key ile sil; emin degilsen match_text ile ilgili kaydi bulup kaldir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {
                    "type": "STRING",
                    "description": "Kaydin kategorisi. Ornek: notes | identity | preferences | projects"
                },
                "key": {
                    "type": "STRING",
                    "description": "Silinecek anahtar. Ornek: claude_limit_refresh"
                },
                "match_text": {
                    "type": "STRING",
                    "description": "Kaydi bulmak icin kullanilacak dogal dil parcasi. Ornek: 'claude ai limit yenilenmesi'"
                }
            }
        }
    },
    {
        "name": "search_memory",
        "description": "Hafızadaki kayıtlar arasında anahtar kelime arar. Kullanıcı bir şeyi hatırlamamı veya daha önce kaydedilmiş bilgiyi bulmamı istediğinde kullan.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {"type": "STRING", "description": "Aranacak ifade"},
                "category": {"type": "STRING", "description": "Opsiyonel kategori filtresi"},
                "limit": {"type": "NUMBER", "description": "Maksimum sonuç sayısı"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "list_memory",
        "description": "Hafızadaki kayıtları özetler ve listeler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {"type": "STRING", "description": "Opsiyonel kategori filtresi"},
                "limit": {"type": "NUMBER", "description": "Maksimum kayıt sayısı"}
            }
        }
    },
    {
        "name": "get_clipboard_text",
        "description": "Panodaki yazıyı okur. Kullanıcı kopyalanmış metni görmek istediğinde kullan.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "set_clipboard_text",
        "description": "Metni panoya yazar. Kullanıcı bir metni kopyalamak istediğinde kullan.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "text": {"type": "STRING", "description": "Panoya yazılacak metin"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "open_path",
        "description": "Windows'ta dosya, klasör veya yerel bir yolu açar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "path": {"type": "STRING", "description": "Açılacak dosya/klasör yolu"}
            },
            "required": ["path"]
        }
    },
    {
        "name": "search_files",
        "description": "Belirli bir klasörde güvenli dosya araması yapar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "Arama kök klasörü"},
                "pattern": {"type": "STRING", "description": "Örnek: *.txt"},
                "max_results": {"type": "NUMBER", "description": "Maksimum sonuç sayısı"}
            },
            "required": ["root"]
        }
    },
    {
        "name": "open_settings",
        "description": "Windows Ayarlar uygulamasını açar. İsteğe bağlı bölümle açabilir.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "section": {"type": "STRING", "description": "display | sound | network | wifi | apps | notifications | privacy"}
            }
        }
    },
    {
        "name": "show_desktop",
        "description": "Masaüstünü gösterir.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "lock_screen",
        "description": "Bilgisayarı kilitler.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "send_whatsapp_message",
        "description": (
            "WhatsApp Desktop veya WhatsApp Web üzerinden mesaj taslağı açar veya mesajı gönderir. "
            "Kişi adı veya telefon numarasıyla çalışabilir. "
            "Telefon numarası verilmemişse kişi adını önce kayıtlı WhatsApp kişileri ve içe aktarılan telefon rehberinde ara. "
            "Kullanıcı 'gönder', 'yolla', 'ile', 'hemen gönder' gibi açık bir gönderme niyeti söylüyorsa "
            "ekstra onay istemeden send_now=true kullan. "
            "Yalnızca 'hazırla', 'taslak aç', 'yaz ama gönderme' diyorsa send_now=false kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "recipient_name": {
                    "type": "STRING",
                    "description": "Kişi adı. Örn: 'Anne', 'Ahmet', 'Ece'"
                },
                "phone_number": {
                    "type": "STRING",
                    "description": "Uluslararası telefon numarası. Örn: +905551112233"
                },
                "message": {
                    "type": "STRING",
                    "description": "Gönderilecek mesaj içeriği"
                },
                "app_target": {
                    "type": "STRING",
                    "description": "desktop | web | auto. Varsayılan auto, tercihen desktop."
                },
                "send_now": {
                    "type": "BOOLEAN",
                    "description": "true ise sohbet açıldıktan sonra mesajı otomatik gönderir"
                }
            },
            "required": ["message"]
        }
    },
    {
        "name": "save_whatsapp_contact",
        "description": (
            "Sık kullanılan bir WhatsApp kişisini adı ve telefon numarasıyla kalıcı belleğe kaydeder. "
            "Kullanıcı bir kişiyi 'annem', 'Ahmet', 'iş ortağım' gibi tekrar kullanılacak şekilde tanımladığında kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "display_name": {
                    "type": "STRING",
                    "description": "Kaydedilecek kişi adı. Örn: 'Annem', 'Ahmet'"
                },
                "phone_number": {
                    "type": "STRING",
                    "description": "Uluslararası telefon numarası. Örn: +905551112233"
                },
                "aliases": {
                    "type": "STRING",
                    "description": "Virgülle ayrılmış alternatif hitaplar. Örn: 'anne, annem, mom'"
                }
            },
            "required": ["display_name", "phone_number"]
        }
    },
    {
        "name": "open_workspace_item",
        "description": "Desktop veya Downloads altındaki güvenli bir dosya/klasörü açar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Çalışma alanına göre yol"}
            },
            "required": ["root", "relative_path"]
        }
    },
    {
        "name": "create_workspace_folder",
        "description": "Desktop veya Downloads altında yeni bir klasör oluşturur.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Oluşturulacak klasör yolu"}
            },
            "required": ["root", "relative_path"]
        }
    },
    {
        "name": "create_workspace_file",
        "description": "Desktop veya Downloads altında yeni dosya oluşturur. Metin ya da binary içerik yazabilir.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Dosya yolu"},
                "content": {"type": "STRING", "description": "Metin içerik"},
                "content_b64": {"type": "STRING", "description": "Opsiyonel binary içerik (base64)"},
                "overwrite": {"type": "BOOLEAN", "description": "Var olan dosyanın üstüne yaz"}
            },
            "required": ["root", "relative_path"]
        }
    },
    {
        "name": "update_workspace_file",
        "description": "Desktop veya Downloads altındaki dosyanın içeriğini günceller.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Dosya yolu"},
                "content": {"type": "STRING", "description": "Yeni metin içerik"},
                "content_b64": {"type": "STRING", "description": "Opsiyonel binary içerik (base64)"}
            },
            "required": ["root", "relative_path"]
        }
    },
    {
        "name": "append_workspace_file",
        "description": "Desktop veya Downloads altındaki metin dosyasına ekleme yapar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Dosya yolu"},
                "content": {"type": "STRING", "description": "Eklenecek metin"}
            },
            "required": ["root", "relative_path", "content"]
        }
    },
    {
        "name": "read_workspace_file",
        "description": "Desktop veya Downloads altındaki dosyanın içeriğini okur.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Dosya yolu"},
                "max_chars": {"type": "NUMBER", "description": "Maksimum metin uzunluğu"}
            },
            "required": ["root", "relative_path"]
        }
    },
    {
        "name": "list_workspace_items",
        "description": "Desktop veya Downloads altındaki dosya ve klasörleri listeler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Alt klasör yolu"},
                "recursive": {"type": "BOOLEAN", "description": "Alt klasörleri de tara"},
                "max_results": {"type": "NUMBER", "description": "Maksimum sonuç sayısı"}
            },
            "required": ["root"]
        }
    },
    {
        "name": "analyze_file",
        "description": "Yerel dosyanın içeriğini okur, özetler ve uygun dosyalarda ayrıntı çıkarır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "path": {"type": "STRING", "description": "Analiz edilecek yerel dosya yolu"},
                "query": {"type": "STRING", "description": "Belirli bir soru veya odak"},
                "max_chars": {"type": "NUMBER", "description": "Metin dosyalarında okunacak maksimum karakter"}
            },
            "required": ["path"]
        }
    },
    {
        "name": "copy_workspace_item",
        "description": "Desktop veya Downloads altında güvenli bir dosya ya da klasörü kopyalar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Kopyalanacak öğe yolu"},
                "destination_relative_path": {"type": "STRING", "description": "Hedef yol"}
            },
            "required": ["root", "relative_path", "destination_relative_path"]
        }
    },
    {
        "name": "rename_workspace_item",
        "description": "Desktop veya Downloads altında güvenli bir öğeyi yeniden adlandırır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Öğe yolu"},
                "new_name": {"type": "STRING", "description": "Yeni dosya veya klasör adı"}
            },
            "required": ["root", "relative_path", "new_name"]
        }
    },
    {
        "name": "delete_workspace_item",
        "description": "Desktop veya Downloads altında güvenli bir dosya ya da klasörü siler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "root": {"type": "STRING", "description": "desktop | downloads"},
                "relative_path": {"type": "STRING", "description": "Öğe yolu"},
                "recursive": {"type": "BOOLEAN", "description": "Klasör için alt öğeleriyle sil"}
            },
            "required": ["root", "relative_path"]
        }
    },
    {
        "name": "list_local_models",
        "description": "Gemini API tarafında kullanılabilir model seçeneklerini listeler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "host": {"type": "STRING", "description": "Ollama host adresi"}
            }
        }
    },
    {
        "name": "list_app_settings",
        "description": "Uygulama ayarlarının okunabilir özetini verir.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "update_app_settings",
        "description": "İzin verilen uygulama ayarlarını günceller. Model, kontrol ve üretim tercihlerini ayarlamak için kullan.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "updates": {
                    "type": "OBJECT",
                    "description": "Anahtar-değer ayar değişiklikleri"
                }
            },
            "required": ["updates"]
        }
    },
    {
        "name": "get_recent_logs",
        "description": "Son yerel günlük kayıtlarını özetler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "limit": {"type": "NUMBER", "description": "Maksimum kayıt sayısı"},
                "event_type": {"type": "STRING", "description": "İsteğe bağlı kayıt türü"}
            }
        }
    },
    {
        "name": "search_logs",
        "description": "Yerel günlük dosyalarında anahtar kelime arar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {"type": "STRING", "description": "Aranacak metin"},
                "limit": {"type": "NUMBER", "description": "Maksimum sonuç sayısı"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "list_generation_config",
        "description": "Gemini görsel/ses/video üretim ayarlarını gösterir.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "generate_image",
        "description": "Gemini API ile görsel üretir ve bilgisayara kaydeder.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "prompt": {"type": "STRING", "description": "Görsel üretim isteği"},
                "model": {"type": "STRING", "description": "İsteğe bağlı model id"},
                "negative_prompt": {"type": "STRING", "description": "İstenmeyen öğeler"},
                "width": {"type": "NUMBER", "description": "Genişlik"},
                "height": {"type": "NUMBER", "description": "Yükseklik"},
                "steps": {"type": "NUMBER", "description": "Üretim adımı"},
                "seed": {"type": "NUMBER", "description": "İsteğe bağlı seed"}
            },
            "required": ["prompt"]
        }
    },
    {
        "name": "generate_music",
        "description": "Gemini API ile müzik üretir ve ses dosyası olarak kaydeder.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "prompt": {"type": "STRING", "description": "Müzik isteği"},
                "model": {"type": "STRING", "description": "İsteğe bağlı model id"},
                "duration_seconds": {"type": "NUMBER", "description": "Süre"},
                "sample_rate": {"type": "NUMBER", "description": "Örnekleme hızı"}
            },
            "required": ["prompt"]
        }
    },
    {
        "name": "generate_video",
        "description": "Gemini API ile video oluşturur ve MP4 olarak kaydeder.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "prompt": {"type": "STRING", "description": "Video isteği"},
                "model": {"type": "STRING", "description": "İsteğe bağlı model id"},
                "duration_seconds": {"type": "NUMBER", "description": "Süre"},
                "fps": {"type": "NUMBER", "description": "Kare hızı"},
                "width": {"type": "NUMBER", "description": "Genişlik"},
                "height": {"type": "NUMBER", "description": "Yükseklik"},
                "seed": {"type": "NUMBER", "description": "İsteğe bağlı seed"}
            },
            "required": ["prompt"]
        }
    },
    {
        "name": "move_mouse",
        "description": "Fare imlecini güvenli şekilde taşır. GUI kontrolü açık olmalıdır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "x": {"type": "NUMBER"},
                "y": {"type": "NUMBER"},
                "duration": {"type": "NUMBER"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "click_mouse",
        "description": "Fare tıklaması yapar. GUI kontrolü açık olmalıdır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "button": {"type": "STRING"},
                "clicks": {"type": "NUMBER"},
                "interval": {"type": "NUMBER"}
            }
        }
    },
    {
        "name": "scroll_mouse",
        "description": "Fare tekeri kaydırır. GUI kontrolü açık olmalıdır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "amount": {"type": "NUMBER"}
            }
        }
    },
    {
        "name": "drag_mouse",
        "description": "Fareyi sürükler. GUI kontrolü açık olmalıdır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "x": {"type": "NUMBER"},
                "y": {"type": "NUMBER"},
                "duration": {"type": "NUMBER"},
                "button": {"type": "STRING"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "press_keys",
        "description": "Tuş veya kısayol çalıştırır. GUI kontrolü açık olmalıdır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "keys": {"type": "STRING"}
            },
            "required": ["keys"]
        }
    },
    {
        "name": "keyboard_hotkey",
        "description": "Birden fazla tuş kombinasyonunu çalıştırır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "keys": {"type": "STRING"}
            },
            "required": ["keys"]
        }
    },
    {
        "name": "type_text",
        "description": "Aktif pencereye güvenli metin yazar.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "text": {"type": "STRING"},
                "interval": {"type": "NUMBER"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "focus_window",
        "description": "Başlık eşleşen pencereyi öne getirir.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {"type": "STRING"}
            },
            "required": ["title"]
        }
    },
    {
        "name": "emergency_stop",
        "description": "GUI kontrolü için acil durdurma/failsafe durumunu hazırlar.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
],


def get_api_key() -> str:
    cfg = load_app_config()
    return str(cfg.get("gemini_api_key", "") or os.environ.get("GEMINI_API_KEY", "") or "").strip()


def load_system_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except Exception:
        return (
            "Sen JARVIS'sin — Windows'ta çalışan kişisel AI asistanı. "
            "Türkçe konuş. Kısa ve net yanıtlar ver. "
            "Araçları kullanarak görevleri tamamla, asla taklit etme."
        )


def get_model_provider() -> str:
    return str(get_app_config_value("model_provider", "gemini") or "gemini").strip().lower()


def get_gemini_text_model_name() -> str:
    return str(get_app_config_value("gemini_text_model", "gemini-3.1-flash-lite-preview") or "gemini-3.1-flash-lite-preview").strip()


def get_gemini_host() -> str:
    return ""


def is_local_model_mode() -> bool:
    return False


class JarvisLive:
    def __init__(self, ui: JarvisUI):
        self.ui             = ui
        self.session        = None
        self.audio_in_queue = None
        self.out_queue      = None
        self._loop          = None
        self._is_speaking   = False
        self._speaking_lock = threading.Lock()

        self.ui.on_text_command  = self._on_text_command
        self.ui.on_pause_toggle  = self._on_pause_toggle
        self.ui.on_effects_state_change = self._on_effects_state_change
        self._paused             = False

    def _on_pause_toggle(self, paused: bool):
        self._paused = paused

    def _on_effects_state_change(self, enabled: bool):
        pass

    def _focus_ui_section_for_tool(self, tool_name: str, args: dict):
        if tool_name == "sys_info":
            query = str(args.get("query", "")).strip().lower()
            if query in {"time", "saat", "zaman", "date", "tarih"}:
                self.ui.focus_panel("time", duration_ms=5200)
            else:
                self.ui.focus_panel("system", duration_ms=5200)
        elif tool_name == "get_weather":
            self.ui.focus_panel("weather", duration_ms=5600)

    def _is_local_mode(self) -> bool:
        return is_local_model_mode()

    def _tool_manifest_text(self) -> str:
        lines = []
        for tool in TOOL_DECLARATIONS:
            name = tool.get("name", "")
            desc = str(tool.get("description", "")).strip()
            if name:
                lines.append(f"- {name}: {desc}")
        return "\n".join(lines)

    def _build_local_system_prompt(self) -> str:
        now = datetime.datetime.now()
        memory = load_memory()
        mem_str = format_memory_for_prompt(memory)
        base = load_system_prompt()
        tool_manifest = self._tool_manifest_text()
        return (
            f"[ŞU ANKİ ZAMAN]\n{now.strftime('%A, %d %B %Y — %H:%M')}\n\n"
            f"{mem_str}\n\n"
            f"{base}\n\n"
            "[GEMINI API MODU]\n"
            "Sen artık Google Gemini API ile çalışıyorsun. Yanıtların sadece Türkçe olmalı.\n"
            "Kullanıcıya gerekirse araç çağrısı yapabilirsin.\n"
            "Kesin format: Geçerli JSON nesnesi döndür. Şu alanları kullan:\n"
            "{\"reply\": \"kısa yanıt\", \"tool_calls\": [{\"name\": \"tool_name\", \"args\": {}}]}\n"
            "tool_calls boş olabilir. reply her zaman bulunmalı. JSON dışında açıklama yazma.\n\n"
            "İzin verilen araçlar:\n"
            f"{tool_manifest}\n\n"
            "Dosya araçları sadece Desktop ve Downloads altında kullanılabilir.\n"
            "Güvenlik gereği çalışma alanı dışına çıkma.\n"
            "GUI kontrol araçları yalnızca kullanıcı açıkça etkinleştirdiyse kullan.\n"
            "Görsel, müzik ve video üretimi Gemini API üzerinden kullanılabilir."
        )

    def _build_local_followup_prompt(self, original_user_text: str, tool_results: list[str]) -> str:
        result_block = "\n".join(f"- {item}" for item in tool_results)
        return (
            "Kullanıcı isteği:\n"
            f"{original_user_text}\n\n"
            "Araç sonuçları:\n"
            f"{result_block}\n\n"
            "Bu sonuçlara dayanarak kullanıcıya kısa ve net nihai yanıt ver.\n"
            "Sadece JSON nesnesi döndür: {\"reply\": \"...\", \"tool_calls\": []}"
        )
    def _normalize_tool_calls(self, tool_calls):
        if isinstance(tool_calls, dict):
            tool_calls = [tool_calls]
        if not isinstance(tool_calls, list):
            return []
        normalized = []
        for item in tool_calls:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "")).strip()
            args = item.get("args", {})
            if not name:
                continue
            if not isinstance(args, dict):
                args = {}
            normalized.append({"name": name, "args": args})
        return normalized

    def _parse_local_answer(self, raw_text: str) -> tuple[str, list[dict]]:
        parsed = extract_json_object(raw_text)
        if isinstance(parsed, dict):
            reply = str(parsed.get("reply", "") or "").strip()
            tool_calls = self._normalize_tool_calls(parsed.get("tool_calls", []))
            if reply or tool_calls:
                return reply, tool_calls
        cleaned = (raw_text or "").strip()
        return cleaned, []

    def _on_text_command(self, text: str):
        if self._paused:
            return
        self.ui.write_log(f"Siz: {text}")
        if self._is_local_mode():
            if not self._loop:
                self.ui.write_log("ERR: Gemini döngüsü henüz hazır değil.")
                return
            asyncio.run_coroutine_threadsafe(
                self._handle_local_text_command(text),
                self._loop,
            )
            return
        if not self._loop or not self.session:
            self.ui.write_log("ERR: JARVIS bağlantısı henüz hazır değil.")
            return
        asyncio.run_coroutine_threadsafe(
            self.session.send_realtime_input(text=text),
            self._loop
        )

    async def _interrupt_audio(self):
        try:
            if self.audio_in_queue:
                while not self.audio_in_queue.empty():
                    try:
                        self.audio_in_queue.get_nowait()
                    except Exception:
                        break
            if self.session:
                await self.session.send_realtime_input(audio_stream_end=True)
            self.set_speaking(False)
        except Exception:
            pass


    async def _handle_local_text_command(self, text: str):
        self.ui.set_state("THINKING")
        loop = asyncio.get_running_loop()
        try:
            api_key = get_api_key()
            model = str(get_app_config_value("gemini_text_model", "gemini-3.1-flash-lite-preview") or "gemini-3.1-flash-lite-preview").strip()
            system_prompt = self._build_local_system_prompt()

            if not api_key:
                raise RuntimeError("Gemini API anahtarı bulunamadı.")

            raw = await loop.run_in_executor(
                None,
                lambda: gemini_chat(
                    model=model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": text},
                    ],
                    api_key=api_key,
                    temperature=0.2,
                ),
            )
            reply, tool_calls = self._parse_local_answer(raw)
            tool_results = []

            for idx, call in enumerate(tool_calls):
                name = str(call.get("name", "")).strip()
                args = call.get("args", {}) if isinstance(call.get("args", {}), dict) else {}
                fc = SimpleNamespace(id=f"local-{idx}", name=name, args=args)
                fr = await self._execute_tool(fc)
                try:
                    result_text = str(fr.response.get("result", ""))
                except Exception:
                    result_text = str(fr)
                tool_results.append(f"{name}: {result_text}")

            if tool_results:
                followup = await loop.run_in_executor(
                    None,
                    lambda: gemini_chat(
                        model=model,
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": self._build_local_followup_prompt(text, tool_results)},
                        ],
                        api_key=api_key,
                        temperature=0.2,
                    ),
                )
                followup_reply, _ = self._parse_local_answer(followup)
                if followup_reply:
                    reply = followup_reply

            reply = (reply or "").strip()
            if not reply:
                reply = "İşlem tamamlandı."
            self.ui.write_log(f"JARVIS: {reply}")
            speak_text(reply)
            self.ui.set_state("LISTENING")
        except Exception as e:
            traceback.print_exc()
            self.speak_error("local_model", e)
            self.ui.write_log(f"ERR: Gemini hatası — {e}")
            self.ui.set_state("ERROR")


    def set_speaking(self, value: bool):
        with self._speaking_lock:
            self._is_speaking = value
        if value:
            self.ui.set_state("SPEAKING")
        else:
            self.ui.set_state("LISTENING")

    def speak_error(self, tool_name: str, error: str):
        short = str(error)[:120]
        self.ui.write_log(f"ERR: {tool_name} — {short}")
        self.ui.write_debug(f"{tool_name}: {short}", level="ERROR")
        self.ui.set_state("ERROR")

    @staticmethod
    def _result_looks_like_error(result) -> bool:
        text = str(result or "").strip().lower()
        if not text:
            return False
        error_markers = (
            "hata",
            "error",
            "alinamadi",
            "alınamadı",
            "bulunamadi",
            "bulunamadı",
            "acilamadi",
            "açılamadı",
            "tamamlanamadi",
            "tamamlanamadı",
            "gecersiz",
            "geçersiz",
            "izin gerekiyor",
            "izin gerekli",
            "baglanti",
            "bağlantı",
            "gerekli.",
        )
        return any(marker in text for marker in error_markers)

    @staticmethod
    def _should_play_success_sfx(tool_name: str, args: dict, result) -> bool:
        action_tools = {
            "open_app",
            "add_calendar_event",
            "add_reminder",
            "delete_calendar_event",
            "remove_calendar_event",
        }
        if tool_name in action_tools:
            return True

        if tool_name == "send_whatsapp_message":
            text = str(result or "").lower()
            if bool(args.get("send_now", False)):
                return "gönderildi" in text or "gonderildi" in text
            return False

        return False

    @staticmethod
    def _clean_transcript_text(text: str) -> tuple[str, bool]:
        raw = str(text or "")
        had_noise = False
        if CONTROL_TOKEN_RE.search(raw):
            had_noise = True
            raw = CONTROL_TOKEN_RE.sub(" ", raw)
        cleaned = []
        for ch in raw:
            if ch in "\n\r\t" or ord(ch) >= 32:
                cleaned.append(ch)
            else:
                had_noise = True
        normalized = " ".join("".join(cleaned).split())
        return normalized.strip(), had_noise

    def _build_config(self):
        if types is None:
            raise RuntimeError("Gemini SDK kullanılamıyor.")
        memory  = load_memory()
        mem_str = format_memory_for_prompt(memory)
        sys_p   = load_system_prompt()
        now     = datetime.datetime.now()
        time_ctx = f"[ŞU ANKİ ZAMAN]\n{now.strftime('%A, %d %B %Y — %H:%M')}\n\n"

        parts = [time_ctx]
        if mem_str:
            parts.append(mem_str + "\n\n")
        parts.append(sys_p)

        return types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            output_audio_transcription={},
            input_audio_transcription={},
            system_instruction="\n".join(parts),
            realtime_input_config={"automatic_activity_detection": {"disabled": False}},
            tools=[{"function_declarations": TOOL_DECLARATIONS}],
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(
                        voice_name=str(get_app_config_value("voice", "Charon") or "Charon")
                    )
                )
            ),
        )

    async def _execute_tool(self, fc) -> types.FunctionResponse:
        name = fc.name
        args = dict(fc.args or {})
        print(f"[JARVIS] 🔧 {name} {args}")
        log_tool_call(name, args=args, success=True)
        self.ui.set_state("THINKING")

        loop   = asyncio.get_event_loop()
        result = "Tamam."
        had_exception = False

        try:
            if name == "save_memory":
                cat = args.get("category", "notes")
                key = args.get("key", "")
                val = args.get("value", "")
                tags = args.get("tags", "")
                importance = args.get("importance", "normal")
                if key and val:
                    tag_list = [t.strip() for t in str(tags or "").split(",") if t.strip()]
                    result = save_memory_entry(cat, key, val, tags=tag_list, source="assistant", importance=str(importance or "normal"))
                    print(f"[Memory] 💾 {cat}/{key} = {val}")
                else:
                    result = "Anahtar veya değer eksik."

            elif name == "delete_memory":
                result = delete_memory(
                    args.get("category", ""),
                    args.get("key", ""),
                    args.get("match_text", ""),
                )

            elif name == "search_memory":
                result = search_memory(
                    args.get("query", ""),
                    args.get("category", ""),
                    int(args.get("limit", 10) or 10),
                )

            elif name == "list_memory":
                result = list_memory(
                    args.get("category", ""),
                    int(args.get("limit", 50) or 50),
                )

            elif name == "get_clipboard_text":
                result = get_clipboard_text()

            elif name == "set_clipboard_text":
                result = set_clipboard_text(args.get("text", ""))

            elif name == "open_path":
                result = open_path(args.get("path", ""))

            elif name == "search_files":
                result = search_files(
                    args.get("root", ""),
                    args.get("pattern", "*"),
                    int(args.get("max_results", 20) or 20),
                )

            elif name == "open_workspace_item":
                result = open_workspace_item(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                )

            elif name == "copy_workspace_item":
                result = copy_workspace_item(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    args.get("destination_relative_path", ""),
                )

            elif name == "rename_workspace_item":
                result = rename_workspace_item(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    args.get("new_name", ""),
                )

            elif name == "delete_workspace_item":
                result = delete_workspace_item(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    bool(args.get("recursive", False)),
                )

            elif name == "create_workspace_folder":
                result = create_workspace_folder(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                )

            elif name == "create_workspace_file":
                result = create_workspace_file(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    args.get("content", ""),
                    args.get("content_b64", ""),
                    bool(args.get("overwrite", False)),
                )

            elif name == "update_workspace_file":
                result = update_workspace_file(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    args.get("content", ""),
                    args.get("content_b64", ""),
                )

            elif name == "append_workspace_file":
                result = append_workspace_file(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    args.get("content", ""),
                )

            elif name == "read_workspace_file":
                result = read_workspace_file(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    int(args.get("max_chars", 12000) or 12000),
                )

            elif name == "list_workspace_items":
                result = list_workspace_items(
                    args.get("root", "desktop"),
                    args.get("relative_path", ""),
                    bool(args.get("recursive", True)),
                    int(args.get("max_results", 100) or 100),
                )

            elif name == "analyze_file":
                result = analyze_file(
                    args.get("path", ""),
                    args.get("query", ""),
                    int(args.get("max_chars", 12000) or 12000),
                )

            elif name == "analyze_image":
                result = analyze_image(
                    args.get("path", ""),
                    args.get("query", ""),
                )

            elif name == "list_local_models":
                result = "\n".join(f"- {name}" for name in gemini_list_models(get_api_key())) or "Kullanılabilir model bulunamadı."

            elif name == "open_settings":
                result = open_settings(args.get("section", ""))

            elif name == "show_desktop":
                result = show_desktop()

            elif name == "lock_screen":
                result = lock_screen()

            elif name == "open_app":
                r = await loop.run_in_executor(
                    None, lambda: open_app(args.get("app_name", "")))
                result = r or f"{args.get('app_name')} açıldı."

            elif name == "sys_info":
                self._focus_ui_section_for_tool(name, args)
                r = await loop.run_in_executor(
                    None, lambda: sys_info(args.get("query", "all")))
                result = r or "Bilgi alındı."

            elif name == "get_weather":
                self._focus_ui_section_for_tool(name, args)
                r = await loop.run_in_executor(
                    None, lambda: get_weather_summary(args.get("location") or None))
                result = r or "Hava durumu bilgisi alindi."

            elif name == "get_calendar_events":
                r = await loop.run_in_executor(
                    None,
                    lambda: get_calendar_events(
                        args.get("query", "today"),
                        int(args.get("limit", 6) or 6),
                    ),
                )
                result = r or "Takvim bilgisi alindi."

            elif name == "add_calendar_event":
                r = await loop.run_in_executor(
                    None,
                    lambda: add_calendar_event(
                        args.get("title", ""),
                        args.get("start_iso", ""),
                        args.get("end_iso", ""),
                        args.get("notes", ""),
                        args.get("location", ""),
                        args.get("calendar_name", ""),
                        bool(args.get("all_day", False)),
                    ),
                )
                result = r or "Takvim etkinligi eklendi."

            elif name == "delete_calendar_event":
                r = await loop.run_in_executor(
                    None,
                    lambda: delete_calendar_event(
                        args.get("title", ""),
                        args.get("start_iso", ""),
                        args.get("calendar_name", ""),
                        bool(args.get("delete_all_matches", False)),
                    ),
                )
                result = r or "Takvim etkinligi silindi."

            elif name == "get_reminders":
                r = await loop.run_in_executor(
                    None,
                    lambda: get_reminders(
                        args.get("query", "upcoming"),
                        int(args.get("limit", 8) or 8),
                        args.get("list_name", ""),
                    ),
                )
                result = r or "Animsatici bilgisi alindi."

            elif name == "add_reminder":
                r = await loop.run_in_executor(
                    None,
                    lambda: add_reminder(
                        args.get("title", ""),
                        args.get("due_iso", ""),
                        args.get("notes", ""),
                        args.get("list_name", ""),
                        args.get("priority", ""),
                        bool(args.get("all_day", False)),
                    ),
                )
                result = r or "Animsatici eklendi."

            elif name == "browser_control":
                r = await loop.run_in_executor(
                    None, lambda: browser_control(
                        args.get("action"),
                        args.get("url"),
                        args.get("query")
                    ))
                result = r or "Tamam."

            elif name == "shell_run":
                r = await loop.run_in_executor(
                    None, lambda: shell_run(args.get("command", "")))
                result = r or "Komut çalıştırıldı."

            elif name == "play_media":
                r = await loop.run_in_executor(
                    None,
                    lambda: play_media(
                        args.get("query", ""),
                        args.get("provider", "auto"),
                        bool(args.get("autoplay", True)),
                    ),
                )
                result = r or "Medya oynatma başlatıldı."

            elif name == "get_youtube_channel_report":
                r = await loop.run_in_executor(
                    None,
                    lambda: get_youtube_channel_report(
                        args.get("query", "overview"),
                        args.get("handle", ""),
                        int(args.get("video_limit", 6) or 6),
                    ),
                )
                result = r or "YouTube kanal raporu alindi."

            elif name == "analyze_screen":
                r = await loop.run_in_executor(
                    None,
                    lambda: analyze_screen(
                        args.get("query", "Ekranda ne var?"),
                        args.get("target", "active_window"),
                    ),
                )
                result = r or "Ekran analizi tamamlandi."

            elif name == "send_whatsapp_message":
                r = await loop.run_in_executor(
                    None,
                    lambda: send_whatsapp_message(
                        args.get("message", ""),
                        args.get("phone_number", ""),
                        args.get("recipient_name", ""),
                        bool(args.get("send_now", False)),
                        args.get("app_target", "auto"),
                    ),
                )
                result = r or "WhatsApp işlemi tamamlandı."

            elif name == "save_whatsapp_contact":
                r = await loop.run_in_executor(
                    None,
                    lambda: save_whatsapp_contact(
                        args.get("display_name", ""),
                        args.get("phone_number", ""),
                        args.get("aliases", ""),
                    ),
                )
                result = r or "WhatsApp kişisi kaydedildi."

            elif name == "list_app_settings":
                result = list_app_settings()

            elif name == "update_app_settings":
                result = update_app_settings(args.get("updates", {}))

            elif name == "get_recent_logs":
                result = get_recent_events(int(args.get("limit", 50) or 50), args.get("event_type", ""))

            elif name == "search_logs":
                result = search_events(args.get("query", ""), int(args.get("limit", 20) or 20))

            elif name == "list_generation_config":
                result = list_generation_config()

            elif name == "generate_image":
                result = generate_image(
                    args.get("prompt", ""),
                    args.get("model", ""),
                    args.get("negative_prompt", ""),
                    int(args.get("width", 1024) or 1024),
                    int(args.get("height", 1024) or 1024),
                    int(args.get("steps", 24) or 24),
                    args.get("seed", None),
                )

            elif name == "generate_music":
                result = generate_music(
                    args.get("prompt", ""),
                    args.get("model", ""),
                    int(args.get("duration_seconds", 8) or 8),
                    int(args.get("sample_rate", 32000) or 32000),
                )

            elif name == "generate_video":
                result = generate_video(
                    args.get("prompt", ""),
                    args.get("model", ""),
                    int(args.get("duration_seconds", 4) or 4),
                    int(args.get("fps", 8) or 8),
                    int(args.get("width", 768) or 768),
                    int(args.get("height", 768) or 768),
                    args.get("seed", None),
                )

            elif name == "move_mouse":
                result = move_mouse(int(args.get("x", 0) or 0), int(args.get("y", 0) or 0), float(args.get("duration", 0.15) or 0.15))

            elif name == "click_mouse":
                result = click_mouse(
                    args.get("button", "left"),
                    int(args.get("clicks", 1) or 1),
                    float(args.get("interval", 0.05) or 0.05),
                )

            elif name == "scroll_mouse":
                result = scroll_mouse(int(args.get("amount", -500) or -500))

            elif name == "drag_mouse":
                result = drag_mouse(
                    int(args.get("x", 0) or 0),
                    int(args.get("y", 0) or 0),
                    float(args.get("duration", 0.2) or 0.2),
                    args.get("button", "left"),
                )

            elif name == "press_keys":
                result = press_keys(args.get("keys", ""))

            elif name == "keyboard_hotkey":
                result = keyboard_hotkey(args.get("keys", ""))

            elif name == "type_text":
                result = type_text(args.get("text", ""), float(args.get("interval", 0.01) or 0.01))

            elif name == "focus_window":
                result = focus_window(args.get("title", ""))

            elif name == "emergency_stop":
                result = emergency_stop()

            else:
                result = f"Bilinmeyen araç: {name}"

        except Exception as e:
            result = f"Hata: {e}"
            had_exception = True
            traceback.print_exc()
            self.speak_error(name, e)

        tool_failed = self._result_looks_like_error(result)
        if tool_failed:
            if not had_exception:
                self.ui.set_state("ERROR")
        elif self._should_play_success_sfx(name, args, result):
            self.ui.play_success_sfx()

        if not tool_failed and not self.ui.muted:
            self.ui.set_state("LISTENING")

        print(f"[JARVIS] 📤 {name} → {str(result)[:80]}")
        return types.FunctionResponse(
            id=fc.id, name=name,
            response={"result": result}
        )

    async def _send_realtime(self):
        while True:
            msg = await self.out_queue.get()
            await self.session.send_realtime_input(media=msg)

    async def _listen_audio(self):
        if not AUDIO_AVAILABLE:
            print("[JARVIS] 🎤 Mikrofon devre dışı (PyAudio kurulu değil)")
            self.ui.write_log("ERR: Mikrofon desteği için PyAudio gerekli. Yazı modu kullanılabilir.")
            return
        print("[JARVIS] 🎤 Mikrofon başladı")
        stream = await asyncio.to_thread(
            pya.open,
            format=FORMAT, channels=CHANNELS,
            rate=SEND_SAMPLE_RATE, input=True,
            frames_per_buffer=CHUNK_SIZE,
        )
        try:
            while True:
                data = await asyncio.to_thread(
                    stream.read, CHUNK_SIZE, exception_on_overflow=False)
                with self._speaking_lock:
                    jarvis_speaking = self._is_speaking
                if not jarvis_speaking and not self.ui.muted and not self._paused:
                    await self.out_queue.put({"data": data, "mime_type": "audio/pcm"})
        except Exception as e:
            print(f"[JARVIS] ❌ Mikrofon: {e}")
            raise
        finally:
            stream.close()

    async def _receive_audio(self):
        print("[JARVIS] 👂 Alım başladı")
        out_buf, in_buf = [], []
        output_noise = False
        output_noise_samples = []
        try:
            while True:
                async for response in self.session.receive():
                    if response.data:
                        self.audio_in_queue.put_nowait(response.data)

                    if response.server_content:
                        sc = response.server_content

                        if sc.output_transcription and sc.output_transcription.text:
                            self.set_speaking(True)
                            raw_txt = sc.output_transcription.text.strip()
                            if raw_txt:
                                txt, had_noise = self._clean_transcript_text(raw_txt)
                                if had_noise:
                                    output_noise = True
                                    if len(output_noise_samples) < 4:
                                        output_noise_samples.append(raw_txt)
                                if txt:
                                    out_buf.append(txt)

                        if sc.input_transcription and sc.input_transcription.text:
                            txt = sc.input_transcription.text.strip()
                            if txt:
                                in_buf.append(txt)
                                self.ui.mark_user_activity(True)

                        if sc.turn_complete:
                            self.set_speaking(False)

                            full_in = " ".join(in_buf).strip()
                            if full_in:
                                self.ui.write_log(f"Siz: {full_in}")
                            in_buf = []

                            full_out = " ".join(out_buf).strip()
                            if full_out:
                                self.ui.write_log(f"JARVIS: {full_out}")
                                if output_noise_samples:
                                    self.ui.write_debug(
                                        "Kısmen filtrelenen ses transcripti: " + " | ".join(output_noise_samples),
                                        level="WARN",
                                    )
                            elif output_noise:
                                self.ui.write_log("ERR: JARVIS sesli yanıtını çözümlerken bir hata oluştu.")
                                if output_noise_samples:
                                    self.ui.write_debug(
                                        "Filtrelenen ham transcript: " + " | ".join(output_noise_samples),
                                        level="WARN",
                                    )
                                self.ui.set_state("ERROR")
                            out_buf = []
                            output_noise = False
                            output_noise_samples = []

                    if response.tool_call:
                        fn_responses = []
                        for fc in response.tool_call.function_calls:
                            print(f"[JARVIS] 📞 {fc.name}")
                            fr = await self._execute_tool(fc)
                            fn_responses.append(fr)
                        await self.session.send_tool_response(
                            function_responses=fn_responses)

        except Exception as e:
            print(f"[JARVIS] ❌ Alım: {e}")
            traceback.print_exc()
            raise

    async def _play_audio(self):
        print("[JARVIS] 🔊 Ses çalma başladı")
        stream = await asyncio.to_thread(
            pya.open,
            format=FORMAT, channels=CHANNELS,
            rate=RECV_SAMPLE_RATE, output=True,
        )
        try:
            while True:
                chunk = await self.audio_in_queue.get()
                self.set_speaking(True)
                await asyncio.to_thread(stream.write, chunk)
        except Exception as e:
            print(f"[JARVIS] ❌ Ses: {e}")
            raise
        finally:
            self.set_speaking(False)
            stream.close()

    async def run(self):
        self._loop = asyncio.get_running_loop()

        if genai is None:
            raise RuntimeError("Gemini SDK yüklenemedi.")

        api_key = get_api_key()
        if not api_key:
            raise RuntimeError("Gemini API anahtarı eksik. Ayarlardan girin.")

        client = genai.Client(api_key=api_key)

        while True:
            # Duraklatılmışsa bağlanma, bekle
            if self._paused:
                await asyncio.sleep(1)
                continue

            try:
                print("[JARVIS] 🔌 Bağlanıyor...")
                self.ui.set_state("THINKING")
                config = self._build_config()

                async with (
                    client.aio.live.connect(model=LIVE_MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session        = session
                    self._loop          = asyncio.get_event_loop()
                    self.audio_in_queue = asyncio.Queue()
                    self.out_queue      = asyncio.Queue(maxsize=10)

                    print("[JARVIS] ✅ Bağlandı.")
                    self.ui.set_state("LISTENING")
                    self.ui.write_log("SYS: JARVIS hazır. Dinliyorum...")
                    log_system("jarvis_ready_gemini")

                    tg.create_task(self._send_realtime())
                    tg.create_task(self._listen_audio())
                    tg.create_task(self._receive_audio())
                    tg.create_task(self._play_audio())

            except Exception as e:
                print(f"[JARVIS] ⚠️ {e}")
                traceback.print_exc()
                self.set_speaking(False)
                self.ui.write_log(f"ERR: Gemini bağlantısı kesildi veya erişilemiyor — {e}")
                log_error("gemini_baglantisi", error=str(e))
                self.ui.set_state("ERROR")
                print("[JARVIS] 🔄 3 saniyede yeniden bağlanıyor...")
                await asyncio.sleep(3)

def main():
    if os.environ.get("TERM_PROGRAM") == "vscode":
        print("[JARVIS] VS Code icinden baslatildi.")

    ui = JarvisUI()
    start_session("jarvis")

    def runner():
        ui.wait_for_api_key()
        jarvis = JarvisLive(ui)
        try:
            asyncio.run(jarvis.run())
        except KeyboardInterrupt:
            print("\n🔴 Kapatılıyor...")

    threading.Thread(target=runner, daemon=True).start()
    ui.root.mainloop()


if __name__ == "__main__":
    main()
