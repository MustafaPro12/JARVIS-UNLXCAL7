"""Yerel uygulama ayarları için güvenli okuma/yazma yardımcıları."""
from __future__ import annotations

from typing import Any

from app_config import load_app_config, save_app_config

EDITABLE_KEYS = {
    "voice",
    "model_provider",
    "gemini_api_key",
    "gemini_live_model",
    "gemini_text_model",
    "gemini_vision_model",
    "gemini_image_model",
    "gemini_video_model",
    "gemini_music_model",
    "local_only",
    "logging_enabled",
    "workspace_roots",
    "developer_mode",
    "log_retention_days",
    "preferred_text_models",
    "preferred_vision_models",
    "image_backend",
    "image_model_id",
    "music_backend",
    "music_model_id",
    "video_backend",
    "video_model_id",
    "generated_media_dir",
    "gui_control_enabled",
    "control_requires_confirmation",
    "allow_file_actions",
    "allow_model_generation",
    "allow_screen_analysis",
    "memory_policy",
    "max_generation_size",
    "max_music_seconds",
    "max_video_seconds",
}

def list_app_settings() -> str:
    config = load_app_config()
    lines = ["Uygulama ayarları:"]
    for key in sorted(EDITABLE_KEYS):
        if key in config:
            lines.append(f"- {key}: {config.get(key)}")
    return "\n".join(lines)

def update_app_settings(updates: dict[str, Any]) -> str:
    if not isinstance(updates, dict) or not updates:
        return "Güncellenecek ayar bulunamadı."
    allowed = {k: v for k, v in updates.items() if k in EDITABLE_KEYS}
    if not allowed:
        return "İzin verilen ayar anahtarı bulunamadı."
    save_app_config(allowed)
    updated = ", ".join(sorted(allowed))
    return f"Ayarlar güncellendi: {updated}"
