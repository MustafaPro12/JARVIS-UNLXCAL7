"""
Sistem bilgisi — Windows ve çapraz platform.
"""

from __future__ import annotations

import datetime as _dt
import os
import platform
import socket
import subprocess
from pathlib import Path

try:
    import psutil  # type: ignore
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

def sys_info(query: str) -> str:
    query = (query or "").lower().strip()
    results = []

    if query in ("battery", "pil", "all"):
        results.append(_battery())
    if query in ("cpu", "işlemci", "islemci", "all"):
        results.append(_cpu())
    if query in ("ram", "bellek", "memory", "all"):
        results.append(_ram())
    if query in ("disk", "depolama", "all"):
        results.append(_disk())
    if query in ("time", "saat", "zaman", "all"):
        now = _dt.datetime.now()
        results.append(f"Saat: {now.strftime('%H:%M:%S')}")
    if query in ("date", "tarih", "all"):
        now = _dt.datetime.now()
        results.append(f"Tarih: {now.strftime('%d %B %Y, %A')}")
    if query in ("network", "ağ", "ag", "wifi", "all"):
        results.append(_network())
    if query in ("os", "system", "all"):
        results.append(_os_info())
    if query in ("uptime", "all"):
        results.append(_uptime())

    if not results:
        results.append("Bilinmeyen sorgu: battery/cpu/ram/disk/time/date/network/os/uptime/all kullanın.")
    return "\n".join(r for r in results if r)

def _battery() -> str:
    if HAS_PSUTIL:
        try:
            bat = psutil.sensors_battery()
            if bat:
                status = "Şarj oluyor" if bat.power_plugged else "Pilde"
                return f"Pil: %{bat.percent:.0f} — {status}"
        except Exception:
            pass
    return "Pil bilgisi alınamadı."

def _cpu() -> str:
    if HAS_PSUTIL:
        usage = psutil.cpu_percent(interval=0.4)
        count = psutil.cpu_count(logical=True) or 0
        freq = psutil.cpu_freq()
        freq_str = f", {freq.current:.0f} MHz" if freq else ""
        return f"CPU: %{usage:.1f} kullanım — {count} çekirdek{freq_str}"
    return "CPU bilgisi alınamadı."

def _ram() -> str:
    if HAS_PSUTIL:
        vm = psutil.virtual_memory()
        total = vm.total / (1024**3)
        used = vm.used / (1024**3)
        pct = vm.percent
        return f"RAM: {used:.1f}GB / {total:.1f}GB kullanımda (%{pct:.0f})"
    return "RAM bilgisi alınamadı."

def _disk() -> str:
    if HAS_PSUTIL:
        root = Path("C:/") if os.name == "nt" else Path("/")
        du = psutil.disk_usage(str(root))
        total = du.total / (1024**3)
        used = du.used / (1024**3)
        free = du.free / (1024**3)
        return f"Disk ({root}): {used:.1f}GB kullanıldı, {free:.1f}GB boş (toplam {total:.1f}GB)"
    return "Disk bilgisi alınamadı."

def _network() -> str:
    if HAS_PSUTIL:
        try:
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()
            active = []
            for name, iface_stats in stats.items():
                if not iface_stats.isup:
                    continue
                ips = []
                for addr in addrs.get(name, []):
                    if getattr(addr, "family", None) in (socket.AF_INET, socket.AF_INET6):
                        ip = getattr(addr, "address", "")
                        if ip and not ip.startswith("fe80") and ip != "127.0.0.1":
                            ips.append(ip)
                if ips:
                    active.append(f"{name}: {', '.join(ips)}")
            if active:
                return "Ağ: " + " | ".join(active[:3])
        except Exception:
            pass
    try:
        host = socket.gethostname()
        ip = socket.gethostbyname(host)
        if ip and ip != "127.0.0.1":
            return f"Ağ: IP {ip}"
    except Exception:
        pass
    return f"Ağ bağlantısı bulunamadı. ({platform.system()})"


def _os_info() -> str:
    try:
        release = platform.platform()
        return f"İşletim Sistemi: {release}"
    except Exception:
        return "İşletim sistemi bilgisi alınamadı."


def _uptime() -> str:
    if HAS_PSUTIL:
        try:
            boot = psutil.boot_time()
            delta = _dt.datetime.now() - _dt.datetime.fromtimestamp(boot)
            days = delta.days
            hours, rem = divmod(delta.seconds, 3600)
            minutes, _ = divmod(rem, 60)
            return f"Açık kalma süresi: {days} gün {hours} saat {minutes} dakika"
        except Exception:
            pass
    return "Açık kalma süresi alınamadı."
