"""
Takvim araçları — yerel hafızada saklanan Windows uyumlu kayıt sistemi.
"""

from __future__ import annotations

import datetime as dt
import uuid
from typing import Any

from memory.memory_manager import load_memory, update_memory

TR_MONTHS = ["", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
TR_WEEKDAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]


def _parse_iso(value: str) -> dt.datetime | None:
    value = (value or "").strip()
    if not value:
        return None
    try:
        normalized = value.replace("Z", "+00:00")
        parsed = dt.datetime.fromisoformat(normalized)
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone().replace(tzinfo=None)
        return parsed
    except Exception:
        pass
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            parsed = dt.datetime.strptime(value[:len(fmt)], fmt)
            return parsed
        except Exception:
            continue
    return None


def _load_events() -> dict[str, dict[str, Any]]:
    mem = load_memory()
    events = mem.get("calendar_events", {})
    return events if isinstance(events, dict) else {}


def _save_events(events: dict[str, dict[str, Any]]) -> None:
    update_memory({"calendar_events": events})


def _normalize_query(query: str) -> tuple[str, int]:
    q = (query or "").strip().lower()
    if any(token in q for token in ("bugün", "bugun", "today")):
        return "today", 8
    if any(token in q for token in ("yarın", "yarin", "tomorrow")):
        return "tomorrow", 8
    if any(token in q for token in ("hafta", "week")):
        return "week", 12
    if any(token in q for token in ("ay", "month")):
        return "month", 20
    if any(token in q for token in ("hepsi", "tüm", "tum", "all")):
        return "all", 30
    return "upcoming", 8


def _add_months(date_obj: dt.date, months: int) -> dt.date:
    month_index = date_obj.month - 1 + months
    year = date_obj.year + month_index // 12
    month = month_index % 12 + 1
    day = min(date_obj.day, [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1])
    return dt.date(year, month, day)


def _day_label(when: dt.datetime, now: dt.datetime) -> str:
    today = now.date()
    target = when.date()
    if target == today:
        return "bugün"
    if target == today + dt.timedelta(days=1):
        return "yarın"
    if target == today - dt.timedelta(days=1):
        return "dün"
    return f"{when.day} {TR_MONTHS[when.month]} {TR_WEEKDAYS[when.weekday()]}"


def _format_time_range(item: dict[str, Any], now: dt.datetime) -> str:
    start = _parse_iso(str(item.get("start_iso", "")))
    end = _parse_iso(str(item.get("end_iso", "")))
    if not start:
        return "zaman belirtilmemiş"
    if item.get("all_day"):
        return f"{_day_label(start, now)} tüm gün"
    if end and end.date() == start.date():
        return f"{_day_label(start, now)} {start.strftime('%H:%M')}–{end.strftime('%H:%M')}"
    return f"{_day_label(start, now)} {start.strftime('%H:%M')}"


def _format_event_line(item: dict[str, Any], now: dt.datetime) -> str:
    parts = [f"{_format_time_range(item, now)} - {item.get('title', 'Adsız etkinlik')}"]
    if item.get("calendar_name"):
        parts.append(f"[{item['calendar_name']}]")
    if item.get("location"):
        parts.append(f"@ {item['location']}")
    return " ".join(parts)


def get_calendar_events(query: str = "today", limit: int = 6) -> str:
    events = _load_events()
    if not events:
        return "Takvimde kayıtlı etkinlik yok."

    mode, default_limit = _normalize_query(query)
    limit = max(1, int(limit or default_limit))

    now = dt.datetime.now()
    today = now.date()
    tomorrow = today + dt.timedelta(days=1)
    week_end = today + dt.timedelta(days=7)
    month_end = _add_months(today, 1)

    filtered: list[dict[str, Any]] = []
    for item in events.values():
        start = _parse_iso(str(item.get("start_iso", "")))
        if not start:
            continue
        date_only = start.date()
        if mode == "today" and date_only != today:
            continue
        if mode == "tomorrow" and date_only != tomorrow:
            continue
        if mode == "week" and not (today <= date_only <= week_end):
            continue
        if mode == "month" and not (today <= date_only <= month_end):
            continue
        if mode == "upcoming" and date_only < today:
            continue
        filtered.append(item)

    if mode == "all":
        filtered = list(events.values())

    filtered.sort(key=lambda item: (_parse_iso(str(item.get("start_iso", ""))) or dt.datetime.max, str(item.get("title", "")).lower()))
    filtered = filtered[:limit]

    if not filtered:
        return "İstenen aralıkta takvim etkinliği bulunamadı."

    lines = ["Takvim:"]
    for item in filtered:
        lines.append(f"- {_format_event_line(item, now)}")
    return "\n".join(lines)


def add_calendar_event(
    title: str,
    start_iso: str,
    end_iso: str = "",
    notes: str = "",
    location: str = "",
    calendar_name: str = "",
    all_day: bool = False,
) -> str:
    title = (title or "").strip()
    if not title:
        return "Etkinlik başlığı boş olamaz."

    start = _parse_iso(start_iso)
    if not start:
        return "Başlangıç tarihi okunamadı."

    end = _parse_iso(end_iso) if end_iso else None
    if end and end < start:
        start, end = end, start

    events = _load_events()
    event_id = uuid.uuid4().hex[:12]
    events[event_id] = {
        "id": event_id,
        "title": title,
        "start_iso": start.isoformat(timespec="minutes"),
        "end_iso": end.isoformat(timespec="minutes") if end else "",
        "notes": (notes or "").strip(),
        "location": (location or "").strip(),
        "calendar_name": (calendar_name or "").strip() or "Takvim",
        "all_day": bool(all_day),
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
    }
    _save_events(events)

    if all_day:
        return f"Etkinlik eklendi: {title} (tüm gün)"
    if end:
        return f"Etkinlik eklendi: {title} — {start.strftime('%d.%m.%Y %H:%M')} / {end.strftime('%d.%m.%Y %H:%M')}"
    return f"Etkinlik eklendi: {title} — {start.strftime('%d.%m.%Y %H:%M')}"


def delete_calendar_event(
    title: str,
    start_iso: str = "",
    calendar_name: str = "",
    delete_all_matches: bool = False,
) -> str:
    title = (title or "").strip().lower()
    if not title:
        return "Silinecek etkinlik başlığı belirtilmedi."

    start = _parse_iso(start_iso) if start_iso else None
    cal_name = (calendar_name or "").strip().lower()

    events = _load_events()
    if not events:
        return "Eşleşen etkinlik bulunamadı."

    removed = []
    kept: dict[str, dict[str, Any]] = {}
    for event_id, item in events.items():
        item_title = str(item.get("title", "")).strip().lower()
        item_cal = str(item.get("calendar_name", "")).strip().lower()
        item_start = _parse_iso(str(item.get("start_iso", "")))

        matched = title in item_title
        if matched and cal_name and cal_name not in item_cal:
            matched = False
        if matched and start and item_start:
            matched = item_start.date() == start.date()
            if matched and start.time() != dt.time(0, 0):
                matched = abs((item_start - start).total_seconds()) < 60

        if matched:
            removed.append(item)
            if not delete_all_matches and len(removed) >= 1:
                continue
            if delete_all_matches:
                continue
        else:
            kept[event_id] = item

    if not removed:
        return "Eşleşen etkinlik bulunamadı."

    if not delete_all_matches and len(removed) == 1:
        # Sadece ilk eşleşeni silmek için tekrar filtrele.
        deleted_once = False
        kept = {}
        for event_id, item in events.items():
            if deleted_once:
                kept[event_id] = item
                continue
            item_title = str(item.get("title", "")).strip().lower()
            item_cal = str(item.get("calendar_name", "")).strip().lower()
            item_start = _parse_iso(str(item.get("start_iso", "")))
            matched = title in item_title
            if matched and cal_name and cal_name not in item_cal:
                matched = False
            if matched and start and item_start:
                matched = item_start.date() == start.date()
                if matched and start.time() != dt.time(0, 0):
                    matched = abs((item_start - start).total_seconds()) < 60
            if matched:
                deleted_once = True
                continue
            kept[event_id] = item

    _save_events(kept)
    if delete_all_matches:
        return f"{len(removed)} etkinlik silindi."
    deleted = removed[0]
    return f"Etkinlik silindi: {deleted.get('title', 'Adsız etkinlik')}"
