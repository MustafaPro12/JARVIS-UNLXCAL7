"""Windows için güvenli klavye ve fare kontrol yardımcıları."""
from __future__ import annotations

from typing import Any
import time

from app_config import get_app_config_value
from actions.audit_log import log_event

try:
    import pyautogui
except Exception:
    pyautogui = None  # type: ignore[assignment]

if pyautogui:
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.03

def _allowed() -> tuple[bool, str]:
    if not bool(get_app_config_value("gui_control_enabled", False)):
        return False, "GUI kontrolü kapalı. Ayarlardan etkinleştir."
    if pyautogui is None:
        return False, "pyautogui kurulu değil."
    return True, ""

def _log(action: str, **payload: Any) -> None:
    log_event("gui_control_request", action, **payload)

def move_mouse(x: int, y: int, duration: float = 0.15) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    try:
        _log("move_mouse", x=x, y=y, duration=duration)
        pyautogui.moveTo(int(x), int(y), duration=max(0.0, float(duration)))
        return f"Fare taşındı: {int(x)}, {int(y)}"
    except Exception as exc:
        return f"Fare taşınamadı: {exc}"

def click_mouse(button: str = "left", clicks: int = 1, interval: float = 0.05) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    try:
        _log("click_mouse", button=button, clicks=clicks)
        pyautogui.click(button=button or "left", clicks=max(1, int(clicks)), interval=max(0.0, float(interval)))
        return f"Fare tıklandı: {button}, {int(clicks)} kez"
    except Exception as exc:
        return f"Fare tıklanamadı: {exc}"

def scroll_mouse(amount: int = -500) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    try:
        _log("scroll_mouse", amount=amount)
        pyautogui.scroll(int(amount))
        return f"Kaydırma yapıldı: {int(amount)}"
    except Exception as exc:
        return f"Kaydırma yapılamadı: {exc}"

def drag_mouse(x: int, y: int, duration: float = 0.2, button: str = "left") -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    try:
        _log("drag_mouse", x=x, y=y, duration=duration, button=button)
        pyautogui.dragTo(int(x), int(y), duration=max(0.0, float(duration)), button=button or "left")
        return f"Fare sürüklendi: {int(x)}, {int(y)}"
    except Exception as exc:
        return f"Fare sürüklenemedi: {exc}"

def press_keys(keys: str) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    keys = (keys or "").strip()
    if not keys:
        return "Tuş belirtilmedi."
    try:
        _log("press_keys", keys=keys)
        parts = [k.strip().lower() for k in keys.replace("+", " ").split() if k.strip()]
        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)
        return f"Tuşlar çalıştırıldı: {keys}"
    except Exception as exc:
        return f"Tuşlar çalıştırılamadı: {exc}"

def keyboard_hotkey(keys: list[str] | str) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    try:
        if isinstance(keys, str):
            parts = [k.strip().lower() for k in keys.replace("+", " ").split() if k.strip()]
        else:
            parts = [str(k).strip().lower() for k in keys if str(k).strip()]
        if len(parts) < 2:
            return "En az iki tuş gerekli."
        _log("keyboard_hotkey", keys=parts)
        pyautogui.hotkey(*parts)
        return f"Kısayol çalıştırıldı: {' + '.join(parts)}"
    except Exception as exc:
        return f"Kısayol çalıştırılamadı: {exc}"

def type_text(text: str, interval: float = 0.01) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    text = text or ""
    if not text.strip():
        return "Yazılacak metin boş."
    if len(text) > 2000:
        return "Güvenlik: Yazılacak metin çok uzun."
    try:
        _log("type_text", chars=len(text))
        pyautogui.write(text, interval=max(0.0, float(interval)))
        return "Metin yazıldı."
    except Exception as exc:
        return f"Metin yazılamadı: {exc}"

def focus_window(title: str) -> str:
    ok, msg = _allowed()
    if not ok:
        return msg
    title = (title or "").strip()
    if not title:
        return "Pencere başlığı boş."
    try:
        _log("focus_window", title=title)
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].activate()
                return f"Pencere öne getirildi: {title}"
        except Exception:
            pass
        return f"Pencere bulunamadı: {title}"
    except Exception as exc:
        return f"Pencere odağı değiştirilemedi: {exc}"

def emergency_stop() -> str:
    try:
        if pyautogui is not None:
            pyautogui.FAILSAFE = True
        return "Acil durdurma hazır. Fareyi sol üst köşeye götürerek failsafe tetiklenebilir."
    except Exception as exc:
        return f"Acil durdurma ayarlanamadı: {exc}"
