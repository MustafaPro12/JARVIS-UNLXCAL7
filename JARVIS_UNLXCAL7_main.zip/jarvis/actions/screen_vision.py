"""Windows yerel ekran analizi; Ollama vision veya OCR yedekli."""
from __future__ import annotations

import tempfile
from pathlib import Path

from PIL import Image, ImageGrab, ImageStat

from actions.file_inspector import analyze_image


def _screen_permission_message() -> str:
    return "Ekran görüntüsü alınamadı. Windows ekran yakalama izni veya masaüstü erişimi gerekli olabilir."


def _capture_screen(target: str = "active_window") -> Image.Image:
    try:
        return ImageGrab.grab(all_screens=True)
    except Exception:
        return ImageGrab.grab()


def _image_looks_blank(image: Image.Image) -> bool:
    try:
        stat = ImageStat.Stat(image.convert("L"))
        return stat.stddev and stat.stddev[0] < 1.0
    except Exception:
        return False


from app_config import get_app_config_value


def analyze_screen(query: str = "Ekranda ne var?", target: str = "active_window") -> str:
    if not bool(get_app_config_value("allow_screen_analysis", True)):
        return "Ekran analizi ayarlardan kapalı."
    try:
        image = _capture_screen(target)
    except Exception as exc:
        return f"{_screen_permission_message()} ({exc})"

    if image is None:
        return _screen_permission_message()

    try:
        with tempfile.NamedTemporaryFile(prefix="jarvis-screen-", suffix=".png", delete=False) as tmp:
            image.save(tmp.name)
            temp_path = Path(tmp.name)
        if _image_looks_blank(image):
            pass
        result = analyze_image(str(temp_path), query=query)
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
        return result
    except Exception as exc:
        return f"Ekran analizi yapılamadı: {exc}"
