"""
Uygulama açma — Windows öncelikli, çapraz platform yedekli.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

APP_ALIASES = {
    "chrome": "chrome",
    "google chrome": "chrome",
    "edge": "msedge",
    "microsoft edge": "msedge",
    "firefox": "firefox",
    "brave": "brave",
    "opera": "opera",
    "vscode": "code",
    "vs code": "code",
    "code": "code",
    "notepad": "notepad",
    "editor": "notepad",
    "terminal": "wt",
    "powershell": "powershell",
    "cmd": "cmd",
    "explorer": "explorer",
    "file explorer": "explorer",
    "calculator": "calc",
    "hesap makinesi": "calc",
    "spotify": "spotify",
    "whatsapp": "whatsapp",
    "telegram": "telegram",
    "zoom": "zoom",
    "discord": "discord",
    "slack": "slack",
    "notion": "notion",
    "mail": "outlook",
}

URL_LIKE = {"http", "https", "ftp", "mailto"}

def _normalize_target(app_name: str) -> str:
    app_name = (app_name or "").strip()
    if not app_name:
        return ""
    return APP_ALIASES.get(app_name.lower(), app_name)

def _open_windows_target(target: str) -> tuple[bool, str]:
    try:
        if "://" in target:
            webbrowser.open(target, new=2, autoraise=True)
            return True, "ok"

        resolved = shutil.which(target)
        if resolved:
            os.startfile(resolved)  # type: ignore[attr-defined]
            return True, resolved

        candidate = Path(target)
        if candidate.exists():
            os.startfile(str(candidate))  # type: ignore[attr-defined]
            return True, str(candidate)

        if sys.platform.startswith("win"):
            subprocess.Popen(f'start "" "{target}"', shell=True)
            return True, target

        webbrowser.open(target, new=2, autoraise=True)
        return True, target
    except Exception as exc:
        return False, str(exc)

def open_app(app_name: str) -> str:
    """Uygulamayı açar, başarı/hata mesajı döndürür."""
    if not app_name:
        return "Uygulama adı belirtilmedi."

    target = _normalize_target(app_name)

    # Önce URL/protokol davranışı
    if target.lower().startswith(tuple(f"{scheme}://" for scheme in URL_LIKE)):
        ok, detail = _open_windows_target(target)
        return f"{app_name} açıldı." if ok else f"'{app_name}' açılamadı: {detail}"

    ok, detail = _open_windows_target(target)
    if ok:
        return f"{app_name} açıldı."
    return f"'{app_name}' bulunamadı veya açılamadı: {detail}"
