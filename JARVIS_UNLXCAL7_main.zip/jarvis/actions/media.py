"""
Medya oynatma — Windows, tarayıcı ve çapraz platform yedekleri.
"""

from __future__ import annotations

import os
import subprocess
import urllib.parse
import webbrowser
from pathlib import Path

from actions.browser import browser_control

def _app_exists(path: str) -> bool:
    return bool(path) and Path(path).exists()

def _open_uri(uri: str) -> bool:
    try:
        if os.name == "nt":
            os.startfile(uri)  # type: ignore[attr-defined]
        else:
            webbrowser.open(uri, new=2, autoraise=True)
        return True
    except Exception:
        return False

def _play_youtube(query: str) -> str:
    return browser_control("play_youtube", query=query)

def _play_spotify(query: str, autoplay: bool = True) -> str:
    encoded_query = urllib.parse.quote(query.strip())
    uri = f"spotify:search:{encoded_query}"
    if _open_uri(uri):
        if autoplay:
            return f"Spotify'da açıldı: {query}"
        return f"Spotify içinde '{query}' araması açıldı."
    web_url = f"https://open.spotify.com/search/{encoded_query}"
    webbrowser.open(web_url, new=2, autoraise=True)
    return f"Spotify web araması açıldı: {query}"

def _play_music_app(query: str, autoplay: bool = True) -> str:
    web_url = f"https://music.apple.com/search?term={urllib.parse.quote(query.strip())}"
    webbrowser.open(web_url, new=2, autoraise=True)
    return "Apple Music/ Music uygulaması Windows'ta desteklenmiyor; web araması açıldı."

def play_media(query: str, provider: str = "auto", autoplay: bool = True) -> str:
    if not query or not query.strip():
        return "Çalınacak içerik belirtilmedi."

    provider = (provider or "auto").strip().lower()

    if provider in ("youtube", "web"):
        return _play_youtube(query)
    if provider == "spotify":
        return _play_spotify(query, autoplay=autoplay)
    if provider in ("music", "apple_music"):
        return _play_music_app(query, autoplay=autoplay)

    # auto
    return _play_youtube(query)
