"""Güvenli dosya ve klasör yardımcıları."""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path


def open_path(path: str) -> str:
    path = (path or "").strip()
    if not path:
        return "Yol belirtilmedi."
    target = Path(path).expanduser()
    if not target.exists():
        return "Belirtilen yol bulunamadı."
    try:
        os.startfile(str(target))  # type: ignore[attr-defined]
        return f"Açıldı: {target}"
    except Exception as exc:
        return f"Açılamadı: {exc}"


def search_files(root: str, pattern: str = "*", max_results: int = 20) -> str:
    root_path = Path(root).expanduser()
    if not root_path.exists():
        return "Arama kökü bulunamadı."

    pattern = (pattern or "*").strip() or "*"
    max_results = max(1, int(max_results or 20))
    results: list[str] = []

    try:
        for current_root, dirs, files in os.walk(root_path):
            for name in files:
                if fnmatch.fnmatch(name.lower(), pattern.lower()):
                    results.append(str(Path(current_root) / name))
                    if len(results) >= max_results:
                        break
            if len(results) >= max_results:
                break
    except Exception as exc:
        return f"Dosya araması başarısız: {exc}"

    if not results:
        return "Eşleşen dosya bulunamadı."
    return "Bulunan dosyalar:\n" + "\n".join(f"- {item}" for item in results)


def open_folder_shortcuts(target: str) -> str:
    target = (target or "").strip().lower()
    shortcuts = {
        "desktop": Path.home() / "Desktop",
        "downloads": Path.home() / "Downloads",
        "documents": Path.home() / "Documents",
        "pictures": Path.home() / "Pictures",
        "music": Path.home() / "Music",
        "videos": Path.home() / "Videos",
    }
    if target not in shortcuts:
        return "Bilinmeyen klasör kısayolu."
    return open_path(str(shortcuts[target]))
