"""
TTS (Text-to-Speech) — Windows SAPI ve çapraz platform yedekleri.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import threading
import textwrap

def _escape_powershell(text: str) -> str:
    return text.replace("'", "''")

def _speak_windows(text: str) -> None:
    safe_text = _escape_powershell(text)
    script = textwrap.dedent(f"""
        Add-Type -AssemblyName System.Speech
        $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $synth.Rate = 0
        $synth.Volume = 100
        $synth.Speak('{safe_text}')
    """).strip()
    subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        check=False,
        capture_output=True,
        text=True,
    )

def _speak_macos(text: str) -> None:
    subprocess.run(["say", text], check=False)

def speak_text(text: str, on_done=None, blocking: bool = False):
    """
    Metni sesli olarak okur.
    on_done: okuma bitince çağrılacak fonksiyon (opsiyonel)
    blocking: True ise bitene kadar bekler
    """
    if not text or not text.strip():
        if on_done:
            on_done()
        return

    max_len = 500
    if len(text) > max_len:
        text = text[:max_len] + "..."

    def _run():
        try:
            if shutil.which("powershell"):
                _speak_windows(text)
            elif shutil.which("say"):
                _speak_macos(text)
        except Exception:
            pass
        if on_done:
            on_done()

    if blocking:
        _run()
    else:
        threading.Thread(target=_run, daemon=True).start()

def get_available_voices() -> list[str]:
    """Mevcut sesleri listeler."""
    voices: list[str] = []
    try:
        if shutil.which("powershell"):
            script = textwrap.dedent("""
                Add-Type -AssemblyName System.Speech
                $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
                $synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }
            """).strip()
            result = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True,
                text=True,
                check=False,
            )
            for line in result.stdout.splitlines():
                line = line.strip()
                if line:
                    voices.append(line)
            return voices

        if shutil.which("say"):
            result = subprocess.run(["say", "-v", "?"], capture_output=True, text=True, check=False)
            for line in result.stdout.splitlines():
                line = line.strip()
                if line:
                    voices.append(line.split()[0])
    except Exception:
        pass
    return voices
