"""Gemini API üzerinden görsel, müzik ve video üretimi."""
from __future__ import annotations

import uuid
from pathlib import Path

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None  # type: ignore[assignment]
    types = None  # type: ignore[assignment]

from app_config import get_app_config_value

try:
    from PIL import Image, ImageDraw
except Exception:
    Image = ImageDraw = None  # type: ignore[assignment]

BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT = BASE_DIR / "data" / "generated"


def _output_dir() -> Path:
    raw = str(get_app_config_value("generated_media_dir", "") or "").strip()
    target = Path(raw).expanduser() if raw else DEFAULT_OUTPUT
    target.mkdir(parents=True, exist_ok=True)
    return target


def _safe_name(prefix: str, ext: str) -> Path:
    return _output_dir() / f"{prefix}-{uuid.uuid4().hex[:10]}{ext}"


def _api_key() -> str:
    key = str(get_app_config_value("gemini_api_key", "") or "").strip()
    if not key:
        raise RuntimeError("Gemini API anahtarı bulunamadı.")
    return key


def _client():
    if genai is None:
        raise RuntimeError("google-genai kurulu değil.")
    return genai.Client(api_key=_api_key())


def list_generation_config() -> str:
    lines = [
        "Gemini üretim ayarları:",
        f"- image_model_id: {get_app_config_value('gemini_image_model', 'imagen-4.0-generate-001')}",
        f"- music_model_id: {get_app_config_value('gemini_music_model', 'lyria-3-clip-preview')}",
        f"- video_model_id: {get_app_config_value('gemini_video_model', 'veo-3.1-lite-generate-preview')}",
        f"- generated_media_dir: {_output_dir()}",
    ]
    return "\n".join(lines)


def _fallback_image(prompt: str, width: int, height: int, note: str) -> Path:
    if Image is None or ImageDraw is None:
        raise RuntimeError("Pillow kurulu değil.")
    img = Image.new("RGB", (width, height), (18, 18, 20))
    draw = ImageDraw.Draw(img)
    msg = (note + "\n" + prompt)[:400]
    draw.text((24, 24), msg, fill=(230, 230, 230))
    out = _safe_name("fallback-image", ".png")
    img.save(out)
    return out


def generate_image(
    prompt: str,
    model: str = "",
    negative_prompt: str = "",
    width: int = 1024,
    height: int = 1024,
    steps: int = 24,
    seed: int | None = None,
) -> str:
    prompt = (prompt or "").strip()
    if not bool(get_app_config_value("allow_model_generation", True)):
        return "Model üretimi ayarlardan kapalı."
    if not prompt:
        return "Görsel üretim promptu boş olamaz."
    model_id = (model or str(get_app_config_value("gemini_image_model", "imagen-4.0-generate-001") or "")).strip()
    if not model_id:
        return "Görsel model kimliği boş."
    try:
        client = _client()
        if types is not None:
            config = types.GenerateImagesConfig(number_of_images=1)
        else:
            config = {"number_of_images": 1}
        response = client.models.generate_images(model=model_id, prompt=prompt, config=config)
        generated = getattr(response, "generated_images", None) or []
        if not generated:
            return "Görsel üretilemedi: boş yanıt."
        image_obj = generated[0].image
        out = _safe_name("image", ".png")
        try:
            image_obj.save(out)
        except Exception:
            try:
                image_obj.save(str(out))
            except Exception:
                return f"Görsel oluşturuldu ancak kaydedilemedi: {out}"
        return f"Görsel oluşturuldu: {out}"
    except Exception as exc:
        try:
            fallback = _fallback_image(prompt, width, height, f"Gemini hatası: {exc}")
            return f"Model çalışmadı, basit çıktı üretildi: {fallback}"
        except Exception as inner:
            return f"Görsel üretilemedi: {exc} / {inner}"


def generate_music(
    prompt: str,
    model: str = "",
    duration_seconds: int = 8,
    sample_rate: int = 32000,
) -> str:
    prompt = (prompt or "").strip()
    if not bool(get_app_config_value("allow_model_generation", True)):
        return "Model üretimi ayarlardan kapalı."
    if not prompt:
        return "Müzik promptu boş olamaz."
    model_id = (model or str(get_app_config_value("gemini_music_model", "lyria-3-clip-preview") or "")).strip()
    if not model_id:
        return "Müzik model kimliği boş."
    try:
        client = _client()
        config = None
        if types is not None:
            config = types.GenerateContentConfig(response_modalities=["AUDIO", "TEXT"])
        response = client.models.generate_content(model=model_id, contents=prompt, config=config)
        out = _safe_name("music", ".mp3")
        audio_data = None
        for part in getattr(response, "parts", []) or []:
            inline = getattr(part, "inline_data", None)
            if inline is not None:
                audio_data = inline.data
                break
        if audio_data is None:
            raise RuntimeError("Müzik yanıtında audio bulunamadı.")
        out.write_bytes(audio_data)
        return f"Müzik üretildi: {out}"
    except Exception as exc:
        return f"Müzik üretilemedi: {exc}"


def generate_video(
    prompt: str,
    model: str = "",
    duration_seconds: int = 4,
    fps: int = 8,
    width: int = 768,
    height: int = 768,
    seed: int | None = None,
) -> str:
    prompt = (prompt or "").strip()
    if not bool(get_app_config_value("allow_model_generation", True)):
        return "Model üretimi ayarlardan kapalı."
    if not prompt:
        return "Video promptu boş olamaz."
    model_id = (model or str(get_app_config_value("gemini_video_model", "veo-3.1-lite-generate-preview") or "")).strip()
    if not model_id:
        return "Video model kimliği boş."
    try:
        client = _client()
        operation = client.models.generate_videos(model=model_id, prompt=prompt)
        import time
        deadline = time.time() + max(60, int(duration_seconds) * 20)
        while not getattr(operation, "done", False) and time.time() < deadline:
            time.sleep(5)
            operation = client.operations.get(operation)
        if not getattr(operation, "done", False):
            return "Video üretimi zaman aşımına uğradı."
        generated = operation.response.generated_videos[0]
        out = _safe_name("video", ".mp4")
        client.files.download(file=generated.video, downloadPath=str(out))
        return f"Video oluşturuldu: {out}"
    except Exception as exc:
        return f"Video oluşturulamadı: {exc}"


def generated_media_help() -> str:
    return (
        "Gemini üretimi için ayarlardan şu modelleri seç: "
        "gemini_image_model=imagen-4.0-generate-001, "
        "gemini_music_model=lyria-3-clip-preview, "
        "gemini_video_model=veo-3.1-lite-generate-preview."
    )
