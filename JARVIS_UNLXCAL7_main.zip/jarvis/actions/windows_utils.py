"""Windows'a özel, düşük riskli yardımcılar."""

from __future__ import annotations

import ctypes
import os
import subprocess
import webbrowser


def open_settings(section: str = "") -> str:
    section = (section or "").strip().lower()
    target = "ms-settings:"
    mapping = {
        "bluetooth": "ms-settings:bluetooth",
        "network": "ms-settings:network",
        "wifi": "ms-settings:network-wifi",
        "display": "ms-settings:display",
        "sound": "ms-settings:sound",
        "apps": "ms-settings:appsfeatures",
        "notifications": "ms-settings:notifications",
        "privacy": "ms-settings:privacy",
    }
    target = mapping.get(section, target)
    try:
        os.startfile(target)  # type: ignore[attr-defined]
        return f"Ayarlar açıldı: {section or 'genel'}"
    except Exception:
        try:
            webbrowser.open(target, new=2, autoraise=True)
            return f"Ayarlar açıldı: {section or 'genel'}"
        except Exception as exc:
            return f"Ayarlar açılamadı: {exc}"


def show_desktop() -> str:
    try:
        # Win + D
        user32 = ctypes.windll.user32  # type: ignore[attr-defined]
        VK_LWIN = 0x5B
        VK_D = 0x44
        KEYEVENTF_KEYUP = 0x0002
        user32.keybd_event(VK_LWIN, 0, 0, 0)
        user32.keybd_event(VK_D, 0, 0, 0)
        user32.keybd_event(VK_D, 0, KEYEVENTF_KEYUP, 0)
        user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, 0)
        return "Masaüstü gösterildi."
    except Exception as exc:
        return f"Masaüstü gösterilemedi: {exc}"


def lock_screen() -> str:
    try:
        ctypes.windll.user32.LockWorkStation()  # type: ignore[attr-defined]
        return "Bilgisayar kilitlendi."
    except Exception as exc:
        return f"Kilit ekranı açılamadı: {exc}"


def open_folder(path: str) -> str:
    path = (path or "").strip()
    if not path:
        return "Yol belirtilmedi."
    try:
        os.startfile(path)  # type: ignore[attr-defined]
        return f"Açıldı: {path}"
    except Exception as exc:
        return f"Açılamadı: {exc}"
