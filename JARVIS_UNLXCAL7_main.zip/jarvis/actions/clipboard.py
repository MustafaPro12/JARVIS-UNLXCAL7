"""Kopyala-yapıştır yardımcıları — Windows uyumlu ve güvenli."""

from __future__ import annotations

import tkinter as tk


def get_clipboard_text() -> str:
    try:
        root = tk.Tk()
        root.withdraw()
        text = root.clipboard_get()
        root.destroy()
        return text
    except Exception as exc:
        return f"Panodan veri alınamadı: {exc}"


def set_clipboard_text(text: str) -> str:
    try:
        root = tk.Tk()
        root.withdraw()
        root.clipboard_clear()
        root.clipboard_append(text or "")
        root.update()
        root.destroy()
        return "Metin panoya kopyalandı."
    except Exception as exc:
        return f"Pano yazılamadı: {exc}"
