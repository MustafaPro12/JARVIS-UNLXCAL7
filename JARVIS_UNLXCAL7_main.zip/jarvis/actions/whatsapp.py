"""
WhatsApp mesaj gönderme — Windows, web ve yerel hafıza destekli.
"""

from __future__ import annotations

import re
import urllib.parse
import webbrowser
from typing import Any

from memory.memory_manager import load_memory, update_memory


def _normalize_phone(phone: str) -> str:
    raw = re.sub(r"\D+", "", phone or "")
    if not raw:
        raise ValueError("Telefon numarası belirtilmedi.")
    if raw.startswith("00"):
        raw = raw[2:]
    if raw.startswith("0") and len(raw) > 10:
        raw = raw.lstrip("0")
    if len(raw) < 8:
        raise ValueError("Geçerli bir telefon numarası girin.")
    return raw


def _normalize_lookup(text: str) -> str:
    text = (text or "").strip().lower()
    return (
        text.replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
    )


def _contact_candidates(contact: dict[str, Any]) -> list[str]:
    candidates = []
    for field in ("display_name", "name", "value", "phone", "number"):
        val = str(contact.get(field, "")).strip()
        if val:
            candidates.append(_normalize_lookup(val))
    aliases = contact.get("aliases", [])
    if isinstance(aliases, str):
        aliases = [aliases]
    if isinstance(aliases, list):
        candidates.extend(_normalize_lookup(str(alias)) for alias in aliases if str(alias).strip())
    return [c for c in candidates if c]


def _load_contacts() -> dict[str, dict[str, Any]]:
    mem = load_memory()
    contacts = mem.get("whatsapp_contacts", {})
    return contacts if isinstance(contacts, dict) else {}


def _find_contact(query: str) -> tuple[str, dict[str, Any]] | tuple[None, None]:
    q = _normalize_lookup(query)
    if not q:
        return None, None

    contacts = _load_contacts()
    for phone, contact in contacts.items():
        if not isinstance(contact, dict):
            continue
        if q in _contact_candidates(contact):
            return phone, contact
    return None, None


def _open_in_browser(url: str) -> tuple[bool, str]:
    try:
        webbrowser.open(url, new=2, autoraise=True)
        return True, url
    except Exception as exc:
        return False, str(exc)


def _open_whatsapp(phone_number: str, message: str) -> tuple[bool, str]:
    encoded = urllib.parse.quote(message or "")
    uri = f"whatsapp://send?phone={phone_number}&text={encoded}"
    try:
        import os
        if hasattr(os, "startfile"):
            os.startfile(uri)  # type: ignore[attr-defined]
        else:
            webbrowser.open(uri, new=2, autoraise=True)
        return True, uri
    except Exception:
        fallback = f"https://web.whatsapp.com/send?phone={phone_number}&text={encoded}"
        ok, detail = _open_in_browser(fallback)
        return ok, detail


def save_whatsapp_contact(display_name: str, phone_number: str, aliases: str = "") -> str:
    try:
        phone = _normalize_phone(phone_number)
    except ValueError as exc:
        return str(exc)

    display_name = (display_name or "").strip()
    alias_list = [a.strip() for a in re.split(r"[,;|]", aliases or "") if a.strip()]

    contacts = _load_contacts()
    contacts[phone] = {
        "display_name": display_name or phone,
        "value": phone,
        "aliases": alias_list,
        "updated_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
    }
    update_memory({"whatsapp_contacts": contacts})
    return f"{display_name or phone} kişisi hafızaya kaydedildi."


def send_whatsapp_message(
    message: str,
    phone_number: str = "",
    recipient_name: str = "",
    send_now: bool = False,
    app_target: str = "auto",
) -> str:
    if not message or not message.strip():
        return "Mesaj boş olamaz."

    app_target = (app_target or "auto").strip().lower()
    if app_target not in {"auto", "desktop", "web"}:
        app_target = "auto"

    normalized_phone = ""
    if phone_number and phone_number.strip():
        try:
            normalized_phone = _normalize_phone(phone_number)
        except ValueError as exc:
            return str(exc)

    resolved_name = recipient_name.strip() if recipient_name else ""
    found_phone, contact = _find_contact(resolved_name) if resolved_name else (None, None)

    if contact and not normalized_phone:
        normalized_phone = found_phone or ""
        resolved_name = str(contact.get("display_name", resolved_name)).strip() or resolved_name

    if normalized_phone and resolved_name:
        save_whatsapp_contact(resolved_name, normalized_phone, aliases=", ".join(contact.get("aliases", [])) if isinstance(contact, dict) else "")

    if app_target in {"auto", "desktop"} and normalized_phone:
        ok, detail = _open_whatsapp(normalized_phone, message)
        if ok:
            label = resolved_name or f"+{normalized_phone}"
            if send_now:
                return f"WhatsApp sohbeti açıldı: {label}. Mesaj hazır; bu sürümde otomatik gönderim kapalı."
            return f"WhatsApp sohbeti açıldı: {label}. Mesaj hazır."
        if app_target == "desktop":
            return f"WhatsApp açılamadı: {detail}"

    if normalized_phone:
        url = f"https://web.whatsapp.com/send?phone={normalized_phone}&text={urllib.parse.quote(message)}"
        ok, detail = _open_in_browser(url)
        if ok:
            label = resolved_name or f"+{normalized_phone}"
            return f"WhatsApp Web açıldı: {label}."
        return f"WhatsApp Web açılamadı: {detail}"

    if resolved_name:
        phone, contact = _find_contact(resolved_name)
        if phone:
            ok, detail = _open_whatsapp(phone, message)
            if ok:
                return f"WhatsApp sohbeti açıldı: {resolved_name}."
            return f"WhatsApp açılamadı: {detail}"

    search_url = f"https://web.whatsapp.com/send?text={urllib.parse.quote(message)}"
    webbrowser.open(search_url, new=2, autoraise=True)
    return "Kişi veya numara bulunamadı; WhatsApp Web açıldı."
