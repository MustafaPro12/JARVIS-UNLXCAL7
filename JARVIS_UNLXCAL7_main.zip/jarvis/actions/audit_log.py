"""Yerel, ayrıntılı ve okunabilir olay günlüğü."""
from __future__ import annotations

import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / "data" / "logs"
_LOCK = threading.Lock()
_SESSION_FILE = LOG_DIR / "session.jsonl"


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _sanitize(value: Any, max_len: int = 4000) -> Any:
    if isinstance(value, str):
        value = value.strip()
        return value[:max_len] + "…" if len(value) > max_len else value
    if isinstance(value, dict):
        return {str(k): _sanitize(v, max_len=max_len) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_sanitize(v, max_len=max_len) for v in value]
    return value


def start_session(label: str = "jarvis") -> Path:
    global _SESSION_FILE
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    _SESSION_FILE = LOG_DIR / f"{stamp}-{label}.jsonl"
    _SESSION_FILE.touch(exist_ok=True)
    return _SESSION_FILE


def get_session_file() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return _SESSION_FILE


def log_event(event_type: str, message: str = "", **payload: Any) -> None:
    entry = {
        "ts": _now(),
        "type": event_type,
        "message": message,
        "payload": _sanitize(payload),
    }
    line = json.dumps(entry, ensure_ascii=False)
    with _LOCK:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with open(_SESSION_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def log_conversation(role: str, text: str, **meta: Any) -> None:
    log_event("conversation", text, role=role, **meta)


def log_tool_call(name: str, args: dict[str, Any] | None = None, result: Any = None, success: bool = True) -> None:
    log_event("tool", name, tool=name, args=args or {}, result=result, success=success)


def log_system(message: str, **meta: Any) -> None:
    log_event("system", message, **meta)


def log_error(message: str, **meta: Any) -> None:
    log_event("error", message, **meta)


def get_recent_events(limit: int = 50, event_type: str = "") -> str:
    limit = max(1, int(limit or 50))
    event_type = (event_type or "").strip().lower()
    if not _SESSION_FILE.exists():
        return "Günlük bulunamadı."
    rows = []
    try:
        with open(_SESSION_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                if event_type and str(item.get("type", "")).lower() != event_type:
                    continue
                rows.append(item)
    except Exception as exc:
        return f"Günlük okunamadı: {exc}"
    rows = rows[-limit:]
    if not rows:
        return "Eşleşen günlük kaydı yok."
    lines = ["Son günlük kayıtları:"]
    for item in rows:
        lines.append(f"- {item.get('ts')} [{item.get('type')}] {item.get('message')}")
    return "\n".join(lines)

def search_events(query: str, limit: int = 20) -> str:
    query = (query or "").strip().lower()
    if not query:
        return "Arama ifadesi boş."
    limit = max(1, int(limit or 20))
    if not _SESSION_FILE.exists():
        return "Günlük bulunamadı."
    rows = []
    try:
        with open(_SESSION_FILE, "r", encoding="utf-8") as f:
            for line in f:
                if query not in line.lower():
                    continue
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                rows.append(item)
                if len(rows) >= limit:
                    break
    except Exception as exc:
        return f"Günlük araması başarısız: {exc}"
    if not rows:
        return "Eşleşme bulunamadı."
    lines = ["Günlük eşleşmeleri:"]
    for item in rows:
        lines.append(f"- {item.get('ts')} [{item.get('type')}] {item.get('message')}")
    return "\n".join(lines)
