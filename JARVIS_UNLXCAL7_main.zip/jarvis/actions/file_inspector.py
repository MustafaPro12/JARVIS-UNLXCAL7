"""Yerel dosya ve görsel içerik analizi."""
from __future__ import annotations

import csv
import io
import json
import mimetypes
import zipfile
from dataclasses import dataclass
from pathlib import Path
import xml.etree.ElementTree as ET

from app_config import get_app_config_value
from actions.local_llm import gemini_available, gemini_chat_with_images

try:
    from PIL import Image
except Exception:
    Image = None  # type: ignore[assignment]

try:
    import pytesseract
except Exception:
    pytesseract = None  # type: ignore[assignment]

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None  # type: ignore[assignment]

TEXT_EXTS = {'.txt', '.md', '.rst', '.py', '.js', '.ts', '.json', '.csv', '.yml', '.yaml', '.xml', '.html', '.htm', '.css', '.ini', '.toml', '.log', '.bat', '.ps1'}
IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif', '.tiff', '.tif'}


@dataclass
class FileAnalysis:
    path: Path
    kind: str
    summary: str
    details: list[str]

    def render(self) -> str:
        body = [f"Tür: {self.kind}", f"Yol: {self.path}", f"Özet: {self.summary}"]
        if self.details:
            body.append("Detaylar:")
            body.extend(f"- {item}" for item in self.details)
        return "\n".join(body)


def _safe_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve()


def _read_text(path: Path, max_chars: int = 12000) -> str:
    for encoding in ('utf-8', 'utf-16', 'cp1254', 'latin-1'):
        try:
            text = path.read_text(encoding=encoding, errors='ignore')
            return text[:max_chars]
        except Exception:
            continue
    data = path.read_bytes()
    return data[:max_chars].decode('utf-8', errors='ignore')


def _extract_docx_text(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as zf:
            xml = zf.read('word/document.xml')
    except Exception:
        return ''
    try:
        root = ET.fromstring(xml)
        parts: list[str] = []
        for elem in root.iter():
            if elem.tag.endswith('}t') and elem.text:
                parts.append(elem.text)
        return '\n'.join(parts)
    except Exception:
        return ''


def _extract_xlsx_text(path: Path, max_chars: int = 12000) -> str:
    try:
        with zipfile.ZipFile(path) as zf:
            shared_strings: list[str] = []
            if 'xl/sharedStrings.xml' in zf.namelist():
                try:
                    root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
                    for item in root.iter():
                        if item.tag.endswith('}t') and item.text:
                            shared_strings.append(item.text)
                except Exception:
                    shared_strings = []
            sheet_names = [n for n in zf.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')]
            parts: list[str] = []
            for sheet in sheet_names[:8]:
                try:
                    root = ET.fromstring(zf.read(sheet))
                    for cell in root.iter():
                        if not cell.tag.endswith('}c'):
                            continue
                        value = None
                        cell_type = cell.attrib.get('t', '')
                        for child in cell:
                            if child.tag.endswith('}v') and child.text:
                                value = child.text
                                break
                            if child.tag.endswith('}is'):
                                texts = []
                                for sub in child.iter():
                                    if sub.tag.endswith('}t') and sub.text:
                                        texts.append(sub.text)
                                if texts:
                                    value = ' '.join(texts)
                                    break
                        if value is None:
                            continue
                        if cell_type == 's':
                            try:
                                idx = int(value)
                                if 0 <= idx < len(shared_strings):
                                    value = shared_strings[idx]
                            except Exception:
                                pass
                        parts.append(str(value))
                except Exception:
                    continue
            return '\n'.join(parts)[:max_chars]
    except Exception:
        return ''


def _extract_pptx_text(path: Path, max_chars: int = 12000) -> str:
    try:
        with zipfile.ZipFile(path) as zf:
            slide_names = [n for n in zf.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
            parts: list[str] = []
            for slide in slide_names[:16]:
                try:
                    root = ET.fromstring(zf.read(slide))
                    for elem in root.iter():
                        if elem.tag.endswith('}t') and elem.text:
                            parts.append(elem.text)
                except Exception:
                    continue
            return '\n'.join(parts)[:max_chars]
    except Exception:
        return ''


def _extract_zip_listing(path: Path, max_items: int = 80) -> str:
    try:
        with zipfile.ZipFile(path) as zf:
            items = zf.namelist()[:max_items]
            return '\n'.join(items)
    except Exception:
        return ''


def _extract_pdf_text(path: Path, max_chars: int = 12000) -> str:
    if PdfReader is None:
        return ''
    try:
        reader = PdfReader(str(path))
        parts: list[str] = []
        for page in reader.pages[:8]:
            try:
                parts.append(page.extract_text() or '')
            except Exception:
                continue
        return '\n'.join(parts)[:max_chars]
    except Exception:
        return ''


def _ocr_image(path: Path) -> str:
    if pytesseract is None or Image is None:
        return ''
    try:
        image = Image.open(path)
        return pytesseract.image_to_string(image)[:12000].strip()
    except Exception:
        return ''


def _file_metadata(path: Path) -> list[str]:
    try:
        stat = path.stat()
    except Exception:
        return []
    return [f"Boyut: {stat.st_size} bayt", f"Değiştirilme: {stat.st_mtime:.0f}"]


def _summarize_text(path: Path, text: str) -> FileAnalysis:
    lines = [line for line in text.splitlines() if line.strip()]
    details = _file_metadata(path)
    details.append(f"Satır sayısı: {len(text.splitlines())}")
    if lines:
        details.append(f"İlk satır: {lines[0][:180]}")
    if path.suffix.lower() == '.json':
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                details.append(f"JSON anahtar sayısı: {len(parsed)}")
        except Exception:
            pass
    elif path.suffix.lower() == '.csv':
        try:
            reader = csv.reader(io.StringIO(text))
            rows = list(reader)
            details.append(f"CSV satır sayısı: {len(rows)}")
            if rows:
                details.append(f"Başlıklar: {', '.join(rows[0][:8])}")
        except Exception:
            pass
    summary = text[:800].strip().replace('\n', ' ')
    if len(summary) < len(text):
        summary += '…'
    return FileAnalysis(path=path, kind='text', summary=summary or 'Metin içeriği okundu.', details=details)


def _summarize_binary(path: Path) -> FileAnalysis:
    details = _file_metadata(path)
    mime, _ = mimetypes.guess_type(str(path))
    summary = f"İkili dosya / MIME: {mime or 'bilinmiyor'}"
    return FileAnalysis(path=path, kind='binary', summary=summary, details=details)


def analyze_folder(path: str, max_items: int = 100) -> str:
    target = _safe_path(path)
    if not target.exists():
        return 'Klasör bulunamadı.'
    if not target.is_dir():
        return 'Belirtilen yol klasör değil.'
    items = []
    try:
        for idx, child in enumerate(sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))):
            if idx >= max_items:
                break
            kind = 'klasör' if child.is_dir() else 'dosya'
            items.append(f'- {child.name} ({kind})')
    except Exception as exc:
        return f'Klasör okunamadı: {exc}'
    return (f'Klasör içeriği: {target}\n' + '\n'.join(items)) if items else f'Klasör boş: {target}'


def analyze_file(path: str, query: str = '', max_chars: int = 12000) -> str:
    target = _safe_path(path)
    if not target.exists():
        return 'Dosya bulunamadı.'
    if target.is_dir():
        return analyze_folder(str(target))

    ext = target.suffix.lower()
    if ext in TEXT_EXTS:
        text = _read_text(target, max_chars=max_chars)
        analysis = _summarize_text(target, text)
        if query:
            analysis.details.insert(0, f'Soru: {query}')
        if len(text) > 0:
            analysis.details.append(f'Önizleme: {text[:1200]}')
        return analysis.render()
    if ext == '.docx':
        text = _extract_docx_text(target)
        if text:
            analysis = _summarize_text(target, text)
            if query:
                analysis.details.insert(0, f'Soru: {query}')
            return analysis.render()
    if ext == '.xlsx':
        text = _extract_xlsx_text(target, max_chars=max_chars)
        if text:
            analysis = _summarize_text(target, text)
            if query:
                analysis.details.insert(0, f'Soru: {query}')
            return analysis.render()
    if ext == '.pptx':
        text = _extract_pptx_text(target, max_chars=max_chars)
        if text:
            analysis = _summarize_text(target, text)
            if query:
                analysis.details.insert(0, f'Soru: {query}')
            return analysis.render()
    if ext == '.pdf':
        text = _extract_pdf_text(target, max_chars=max_chars)
        if text:
            analysis = _summarize_text(target, text)
            if query:
                analysis.details.insert(0, f'Soru: {query}')
            return analysis.render()
    if ext in IMAGE_EXTS:
        return analyze_image(path, query=query)
    if ext == '.zip':
        listing = _extract_zip_listing(target)
        if listing:
            return f'ZIP içeriği ({target}):\n{listing}'
    return _summarize_binary(target).render()


def analyze_image(path: str, query: str = '') -> str:
    target = _safe_path(path)
    if not target.exists():
        return 'Görsel bulunamadı.'
    if target.suffix.lower() not in IMAGE_EXTS:
        return 'Belirtilen dosya görsel değil.'

    ocr = _ocr_image(target)
    details = _file_metadata(target)
    if Image is not None:
        try:
            with Image.open(target) as img:
                details.append(f"Çözünürlük: {img.width}x{img.height}")
                details.append(f"Renk modu: {img.mode}")
        except Exception:
            pass

    vision_model = str(get_app_config_value('gemini_vision_model', '') or '').strip()
    api_key = str(get_app_config_value('gemini_api_key', '') or '').strip()
    prompt = query or 'Bu görselde ne var? Önemli yazıları, nesneleri ve bağlamı açıkla.'

    if vision_model and gemini_available(api_key):
        try:
            content = gemini_chat_with_images(
                model=vision_model,
                messages=[
                    {'role': 'system', 'content': 'Sen yerel bir görsel analiz asistanısın. Türkçe, net ve gözleme dayalı cevap ver.'},
                    {'role': 'user', 'content': prompt, 'images': [target]},
                ],
                api_key=api_key,
                temperature=0.2,
            )
            parts = [f'Görsel analizi (Gemini modeli: {vision_model})', content.strip()]
            if ocr:
                parts.append('OCR metni:')
                parts.append(ocr)
            if details:
                parts.append('Detaylar:')
                parts.extend(f'- {item}' for item in details)
            return '\n'.join(parts)
        except Exception:
            pass

    parts = ['Gemini görsel modeli kullanılamadı; OCR ve dosya bilgisi ile analiz edildi.']
    if query:
        parts.append(f'Soru: {query}')
    if ocr:
        parts.append('OCR metni:')
        parts.append(ocr)
    if details:
        parts.append('Detaylar:')
        parts.extend(f'- {item}' for item in details)
    if not ocr:
        parts.append('Not: Bu makinede OCR desteği yok veya görselden metin okunamadı.')
    return '\n'.join(parts)
