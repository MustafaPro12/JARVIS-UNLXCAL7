"""
Basit yerel JSON depolama yardımcıları.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

def _path(name: str) -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR / name

def load_json(name: str, default: Any):
    path = _path(name)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def save_json(name: str, value: Any) -> None:
    path = _path(name)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
