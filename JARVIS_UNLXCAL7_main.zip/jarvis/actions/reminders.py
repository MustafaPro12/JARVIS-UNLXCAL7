"""
Hatırlatıcı araçları — yerel hafızada saklanan Windows uyumlu kayıt sistemi.
"""

from __future__ import annotations

import datetime as dt
import uuid
from typing import Any

from memory.memory_manager import load_memory, update_memory

TR_WEEKDAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
TR_MONTHS = ["", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]


def _parse_iso(value: str) -> dt.datetime | None:
    value = (value or "").strip()
    if not value:
        return None
    try:
        normalized = value.replace("Z", "+00:00")
        parsed = dt.datetime.fromisoformat(normalized)
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone().replace(tzinfo=None)
        return parsed
    except Exception:
        pass
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(value[:len(fmt)], fmt)
        except Exception:
            continue
    return None


def _load_reminders() -> dict[str, dict[str, Any]]:
    mem = load_memory()
    reminders = mem.get("reminders", {})
    return reminders if isinstance(reminders, dict) else {}


def _save_reminders(reminders: dict[str, dict[str, Any]]) -> None:
    update_memory({"reminders": reminders})


def _normalize_query(query: str) -> str:
    q = (query or "").strip().lower()
    if any(token in q for token in ("bugün", "bugun", "today")):
        return "today"
    if any(token in q for token in ("yarın", "yarin", "tomorrow")):
        return "tomorrow"
    if any(token in q for token in ("gecik", "overdue")):
        return "overdue"
    if any(token in q for token in ("hepsi", "tüm", "tum", "all")):
        return "all"
    if any(token in q for token in ("sıradaki", "siradaki", "next")):
        return "next"
    return "upcoming"


def _label(dt_obj: dt.datetime) -> str:
    weekday = TR_WEEKDAYS[dt_obj.weekday()]
    return f"{dt_obj.day} {TR_MONTHS[dt_obj.month]} {weekday}"


def _format_due(item: dict[str, Any], now: dt.datetime) -> str:
    due = _parse_iso(str(item.get("due_iso", "")))
    if not due:
        return "tarih belirtilmemiş"
    if item.get("all_day"):
        return f"{_label(due)} tüm gün"
    if due.date() == now.date():
        return f"bugün {due.strftime('%H:%M')}"
    if due.date() == now.date() + dt.timedelta(days=1):
        return f"yarın {due.strftime('%H:%M')}"
    return f"{_label(due)} {due.strftime('%H:%M')}"


def get_reminders(query: str = "upcoming", limit: int = 8, list_name: str = "") -> str:
    reminders = _load_reminders()
    if not reminders:
        return "Kaydedilmiş hatırlatıcı yok."

    mode = _normalize_query(query)
    limit = max(1, int(limit or 8))
    list_name = (list_name or "").strip().lower()
    now = dt.datetime.now()
    today = now.date()

    filtered: list[dict[str, Any]] = []
    for item in reminders.values():
        due = _parse_iso(str(item.get("due_iso", "")))
        if list_name and list_name not in str(item.get("list_name", "")).lower():
            continue
        if mode == "today" and (not due or due.date() != today):
            continue
        if mode == "tomorrow" and (not due or due.date() != today + dt.timedelta(days=1)):
            continue
        if mode == "overdue" and (not due or due.date() >= today):
            continue
        if mode == "next" and (not due or due.date() < today):
            continue
        if mode == "upcoming" and due and due.date() < today:
            continue
        filtered.append(item)

    if mode == "all":
        filtered = list(reminders.values())

    filtered.sort(key=lambda item: (_parse_iso(str(item.get("due_iso", ""))) or dt.datetime.max, str(item.get("title", "")).lower()))
    filtered = filtered[:limit]

    if not filtered:
        return "İstenen aralıkta hatırlatıcı bulunamadı."

    lines = ["Hatırlatıcılar:"]
    for item in filtered:
        parts = [f"{_format_due(item, now)} - {item.get('title', 'Adsız hatırlatıcı')}"]
        if item.get("list_name"):
            parts.append(f"[{item['list_name']}]")
        if item.get("priority"):
            parts.append(f"({item['priority']})")
        lines.append("- " + " ".join(parts))
    return "\n".join(lines)


def add_reminder(
    title: str,
    due_iso: str = "",
    notes: str = "",
    list_name: str = "",
    priority: str = "",
    all_day: bool = False,
) -> str:
    title = (title or "").strip()
    if not title:
        return "Hatırlatıcı başlığı boş olamaz."

    due = _parse_iso(due_iso) if due_iso else None
    if due_iso and not due:
        return "Hatırlatıcı tarihi okunamadı."

    reminders = _load_reminders()
    reminder_id = uuid.uuid4().hex[:12]
    reminders[reminder_id] = {
        "id": reminder_id,
        "title": title,
        "due_iso": due.isoformat(timespec="minutes") if due else "",
        "notes": (notes or "").strip(),
        "list_name": (list_name or "").strip() or "Hatırlatıcılar",
        "priority": (priority or "").strip().lower() or "medium",
        "all_day": bool(all_day),
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
    }
    _save_reminders(reminders)

    if due:
        return f"Hatırlatıcı eklendi: {title} — {due.strftime('%d.%m.%Y %H:%M')}"
    return f"Hatırlatıcı eklendi: {title}"
