"""Gemini API yardımcıları.

Bu modül geriye dönük uyumluluk için eski `ollama_*` isimlerini korur,
ancak tamamı Google GenAI / Gemini API ile çalışır.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None  # type: ignore[assignment]
    types = None  # type: ignore[assignment]

from app_config import get_app_config_value


def _api_key(api_key: str | None = None) -> str:
    key = str(api_key or get_app_config_value("gemini_api_key", "") or os.getenv("GEMINI_API_KEY", "") or "").strip()
    if not key:
        raise RuntimeError("Gemini API anahtarı bulunamadı. Ayarlardan girin veya GEMINI_API_KEY değişkenini tanımlayın.")
    return key


def _client(api_key: str | None = None):
    if genai is None:
        raise RuntimeError("google-genai paketi kurulu değil.")
    return genai.Client(api_key=_api_key(api_key))


def _read_image_bytes(image: Any) -> tuple[bytes, str] | None:
    if image is None:
        return None
    if isinstance(image, Path):
        image = str(image)
    if isinstance(image, (bytes, bytearray)):
        return bytes(image), "image/png"
    if isinstance(image, str):
        path = Path(image)
        if not path.exists():
            return None
        data = path.read_bytes()
        mime = "image/jpeg"
        suffix = path.suffix.lower()
        if suffix == ".png":
            mime = "image/png"
        elif suffix == ".webp":
            mime = "image/webp"
        elif suffix == ".gif":
            mime = "image/gif"
        elif suffix == ".bmp":
            mime = "image/bmp"
        return data, mime
    return None


def gemini_available(api_key: str | None = None) -> bool:
    try:
        return bool(_api_key(api_key))
    except Exception:
        return False


def _messages_to_contents(messages: list[dict[str, Any]]) -> list[Any] | str:
    if not messages:
        return ""
    parts: list[Any] = []
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        content = str(msg.get("content", "") or "").strip()
        images = msg.get("images") or []
        if images and types is not None:
            if isinstance(images, (str, Path, bytes, bytearray)):
                images = [images]
            for image in images:
                image_pack = _read_image_bytes(image)
                if image_pack:
                    data, mime = image_pack
                    parts.append(types.Part.from_bytes(data=data, mime_type=mime))
        if content:
            parts.append(content)
    return parts or ""


def _response_text(response: Any) -> str:
    text = getattr(response, "text", None)
    if isinstance(text, str) and text.strip():
        return text.strip()
    pieces: list[str] = []
    for part in getattr(response, "parts", []) or []:
        ptext = getattr(part, "text", None)
        if ptext:
            pieces.append(str(ptext))
    return "\n".join(pieces).strip()


def gemini_chat(
    model: str,
    messages: list[dict[str, Any]],
    api_key: str | None = None,
    temperature: float = 0.2,
    max_output_tokens: int = 1024,
) -> str:
    client = _client(api_key)
    config = None
    if types is not None:
        try:
            config = types.GenerateContentConfig(
                temperature=float(temperature),
                max_output_tokens=int(max_output_tokens),
            )
        except Exception:
            config = None
    response = client.models.generate_content(
        model=model,
        contents=_messages_to_contents(messages),
        config=config,
    )
    return _response_text(response)


def gemini_chat_with_images(
    model: str,
    messages: list[dict[str, Any]],
    api_key: str | None = None,
    temperature: float = 0.2,
    max_output_tokens: int = 1024,
) -> str:
    return gemini_chat(model=model, messages=messages, api_key=api_key, temperature=temperature, max_output_tokens=max_output_tokens)


def extract_json_object(text: str) -> dict[str, Any] | None:
    raw = (text or "").strip()
    if not raw:
        return None
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        pass

    start = raw.find("{")
    if start < 0:
        return None

    depth = 0
    in_string = False
    escape = False
    for idx in range(start, len(raw)):
        ch = raw[idx]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                candidate = raw[start:idx + 1]
                try:
                    parsed = json.loads(candidate)
                    return parsed if isinstance(parsed, dict) else None
                except Exception:
                    return None
    return None


def gemini_list_models(api_key: str | None = None) -> list[str]:
    try:
        client = _client(api_key)
        result = client.models.list()
        models: list[str] = []
        for item in result:
            name = str(getattr(item, "name", "") or "").strip()
            if name:
                models.append(name.split("/")[-1])
        return sorted(dict.fromkeys(models), key=str.lower)
    except Exception:
        return []


def gemini_pull_model(model: str, api_key: str | None = None) -> str:
    model = (model or "").strip()
    if not model:
        return "Model adı boş olamaz."
    return f"Gemini modelleri bulutta yönetilir. Bu model için yerelde indirme gerekmez: {model}"


ollama_available = gemini_available
ollama_chat = gemini_chat
ollama_chat_with_images = gemini_chat_with_images
ollama_list_models = gemini_list_models
ollama_pull_model = gemini_pull_model
