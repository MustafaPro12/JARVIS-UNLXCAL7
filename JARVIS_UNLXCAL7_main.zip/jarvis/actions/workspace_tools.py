"""Güvenli masaüstü ve indirilenler çalışma alanı araçları."""

from __future__ import annotations

import base64
import os
from pathlib import Path
from typing import Iterable

SAFE_ROOTS = {
    "desktop": Path.home() / "Desktop",
    "downloads": Path.home() / "Downloads",
}


def _normalize_root(root_name: str) -> str:
    root = (root_name or "").strip().lower()
    aliases = {
        "d": "desktop",
        "masaustu": "desktop",
        "masaüstü": "desktop",
        "indirilenler": "downloads",
        "download": "downloads",
        "downloads": "downloads",
        "desktop": "desktop",
    }
    return aliases.get(root, root)


def _safe_root(root_name: str) -> tuple[Path | None, str]:
    root_key = _normalize_root(root_name)
    root = SAFE_ROOTS.get(root_key)
    if not root:
        return None, "Geçersiz çalışma alanı. 'desktop' veya 'downloads' kullan."
    root.mkdir(parents=True, exist_ok=True)
    return root, root_key


def _resolve_safe_path(root_name: str, relative_path: str) -> tuple[Path | None, str]:
    root, root_key = _safe_root(root_name)
    if not root:
        return None, root_key

    rel = (relative_path or "").strip().replace("\\", "/")
    if not rel:
        return root, root_key

    candidate = (root / rel).expanduser()
    try:
        root_resolved = root.resolve()
        cand_resolved = candidate.resolve(strict=False)
    except Exception:
        return None, "Yol çözümlenemedi."

    if cand_resolved == root_resolved or root_resolved in cand_resolved.parents:
        return cand_resolved, root_key
    return None, "Güvenlik: Çalışma alanı dışına çıkılamaz."


def _write_file(target: Path, content: str = "", content_b64: str = "", overwrite: bool = False) -> str:
    if target.exists() and not overwrite:
        return f"Dosya zaten var: {target}"

    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        if content_b64:
            data = base64.b64decode(content_b64.encode("utf-8"))
            target.write_bytes(data)
        else:
            target.write_text(content or "", encoding="utf-8")
    except Exception as exc:
        return f"Dosya yazılamadı: {exc}"
    return f"Kaydedildi: {target}"


def create_workspace_folder(root_name: str, relative_path: str) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    try:
        target.mkdir(parents=True, exist_ok=True)
        return f"Klasör oluşturuldu: {target}"
    except Exception as exc:
        return f"Klasör oluşturulamadı: {exc}"


def list_workspace_items(root_name: str, relative_path: str = "", recursive: bool = True, max_results: int = 100) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    if not target.exists():
        return "Klasör bulunamadı."

    max_results = max(1, int(max_results or 100))
    items: list[str] = []
    try:
        walker: Iterable[Path] = target.rglob("*") if recursive else target.iterdir()
        for item in walker:
            suffix = "/" if item.is_dir() else ""
            items.append(str(item.relative_to(target)) + suffix)
            if len(items) >= max_results:
                break
    except Exception as exc:
        return f"Listeleme başarısız: {exc}"

    if not items:
        return "Öğe bulunamadı."
    return "Çalışma alanı içeriği:\n" + "\n".join(f"- {item}" for item in items)


def read_workspace_file(root_name: str, relative_path: str, max_chars: int = 12000) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    if not target.exists():
        return "Dosya bulunamadı."
    if target.is_dir():
        return "Belirtilen yol bir klasör."

    max_chars = max(1, int(max_chars or 12000))
    try:
        data = target.read_bytes()
        try:
            text = data.decode("utf-8")
            if len(text) > max_chars:
                text = text[:max_chars] + "\n... (metin kısaltıldı)"
            return f"Dosya içeriği ({target}):\n{text}"
        except UnicodeDecodeError:
            preview = base64.b64encode(data[: min(len(data), 4096)]).decode("ascii")
            return (
                f"Bu dosya metin olarak okunamadı: {target}\n"
                f"Binary önizleme (base64, ilk bölüm):\n{preview}"
            )
    except Exception as exc:
        return f"Dosya okunamadı: {exc}"


def create_workspace_file(
    root_name: str,
    relative_path: str,
    content: str = "",
    content_b64: str = "",
    overwrite: bool = False,
) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    if target.exists() and target.is_dir():
        return "Belirtilen yol bir klasör; dosya oluşturulamaz."
    return _write_file(target, content=content, content_b64=content_b64, overwrite=overwrite)


def update_workspace_file(
    root_name: str,
    relative_path: str,
    content: str = "",
    content_b64: str = "",
) -> str:
    return create_workspace_file(
        root_name=root_name,
        relative_path=relative_path,
        content=content,
        content_b64=content_b64,
        overwrite=True,
    )


def append_workspace_file(root_name: str, relative_path: str, content: str = "") -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    if target.exists() and target.is_dir():
        return "Belirtilen yol bir klasör; dosyaya ekleme yapılamaz."
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(target, "a", encoding="utf-8") as f:
            f.write(content or "")
    except Exception as exc:
        return f"Dosyaya ekleme başarısız: {exc}"
    return f"Metin eklendi: {target}"


def open_workspace_item(root_name: str, relative_path: str) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    if not target.exists():
        return "Belirtilen yol bulunamadı."
    try:
        os.startfile(str(target))  # type: ignore[attr-defined]
        return f"Açıldı: {target}"
    except Exception as exc:
        return f"Açılamadı: {exc}"


def delete_workspace_item(root_name: str, relative_path: str, recursive: bool = False) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    if not target.exists():
        return "Belirtilen öğe bulunamadı."
    try:
        if target.is_dir():
            if recursive:
                import shutil
                shutil.rmtree(target)
            else:
                target.rmdir()
        else:
            target.unlink()
        return f"Silindi: {target}"
    except Exception as exc:
        return f"Silme başarısız: {exc}"


def rename_workspace_item(root_name: str, relative_path: str, new_name: str) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    new_name = (new_name or '').strip()
    if not new_name:
        return 'Yeni ad boş olamaz.'
    try:
        renamed = target.with_name(new_name)
        target.rename(renamed)
        return f'Yeniden adlandırıldı: {renamed}'
    except Exception as exc:
        return f'Yeniden adlandırma başarısız: {exc}'


def copy_workspace_item(root_name: str, relative_path: str, destination_relative_path: str) -> str:
    target, msg = _resolve_safe_path(root_name, relative_path)
    if not target:
        return msg
    dest, msg2 = _resolve_safe_path(root_name, destination_relative_path)
    if not dest:
        return msg2
    try:
        if target.is_dir():
            import shutil
            shutil.copytree(target, dest, dirs_exist_ok=True)
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            import shutil
            shutil.copy2(target, dest)
        return f'Kopyalandı: {target} -> {dest}'
    except Exception as exc:
        return f'Kopyalama başarısız: {exc}'
