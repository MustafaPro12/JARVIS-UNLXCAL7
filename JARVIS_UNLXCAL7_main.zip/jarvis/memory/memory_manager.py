"""
Kalıcı bellek — tek bir yerel JSON dosyasına kaydedilir.
Windows sürümü için genişletilmiş, aranabilir ve geriye uyumlu yapı.
"""

from __future__ import annotations

import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
MEMORY_FILE = BASE_DIR / "memory" / "memory.json"
DEFAULT_VERSION = 2


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure_shape(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {}

    # Eski sürümden geliyorsa olduğu gibi koru; sadece reserved alan ekle.
    memory = dict(raw)
    memory.setdefault("_meta", {})
    if not isinstance(memory["_meta"], dict):
        memory["_meta"] = {}
    memory["_meta"].setdefault("version", DEFAULT_VERSION)
    memory["_meta"].setdefault("updated_at", _now_iso())
    memory["_meta"].setdefault("created_at", memory["_meta"].get("updated_at", _now_iso()))
    return memory


def load_memory() -> dict:
    try:
        if MEMORY_FILE.exists():
            with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
                return _ensure_shape(raw)
    except Exception:
        pass
    return {"_meta": {"version": DEFAULT_VERSION, "created_at": _now_iso(), "updated_at": _now_iso()}}


def _write_memory(mem: dict):
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    mem = _ensure_shape(mem)
    mem["_meta"]["version"] = DEFAULT_VERSION
    mem["_meta"]["updated_at"] = _now_iso()
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(mem, f, indent=2, ensure_ascii=False)


def _deep_merge(base: dict, update: dict):
    for k, v in update.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v


def _normalize_text(text: str) -> str:
    text = (text or "").strip().casefold()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.replace("ı", "i")
    return " ".join(text.split())


def _entry_value_text(value) -> str:
    if isinstance(value, dict):
        if "value" in value:
            return str(value.get("value", ""))
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _tokenize_text(text: str) -> list[str]:
    normalized = _normalize_text(text)
    return [token for token in re.split(r"[^a-z0-9]+", normalized) if token]


def _entry_matches(needle: str, category: str, item_key: str, item_value) -> bool:
    haystacks = [
        _normalize_text(category),
        _normalize_text(item_key),
        _normalize_text(_entry_value_text(item_value)),
    ]
    if any(needle in hay for hay in haystacks):
        return True

    tokens = [tok for tok in _tokenize_text(needle) if len(tok) >= 3]
    if not tokens:
        return False

    entry_tokens: list[str] = []
    for hay in haystacks:
        entry_tokens.extend(_tokenize_text(hay))

    matched = 0
    for token in tokens:
        if any(token in entry_token or entry_token in token for entry_token in entry_tokens):
            matched += 1

    if len(tokens) == 1:
        return matched == 1
    return matched >= min(2, len(tokens))


def _prepare_memory_entry(value, tags=None, source: str = "user", importance: str = "normal") -> dict:
    if isinstance(value, dict) and any(k in value for k in ("value", "tags", "source", "importance", "notes")):
        record = dict(value)
        record.setdefault("source", source)
        record.setdefault("importance", importance)
        record.setdefault("created_at", _now_iso())
        record.setdefault("updated_at", _now_iso())
        if tags is not None and not record.get("tags"):
            record["tags"] = list(tags) if isinstance(tags, (list, tuple, set)) else [str(tags)]
        return record

    record = {
        "value": value,
        "tags": list(tags) if isinstance(tags, (list, tuple, set)) else ([str(tags)] if tags else []),
        "source": source,
        "importance": importance,
        "created_at": _now_iso(),
        "updated_at": _now_iso(),
    }
    return record


def save_memory_entry(
    category: str,
    key: str,
    value,
    tags=None,
    source: str = "user",
    importance: str = "normal",
) -> str:
    category = (category or "notes").strip() or "notes"
    key = (key or "").strip()
    if not key:
        return "Anahtar boş olamaz."

    mem = load_memory()
    bucket = mem.get(category)
    if not isinstance(bucket, dict):
        bucket = {}
    bucket[key] = _prepare_memory_entry(value, tags=tags, source=source, importance=importance)
    mem[category] = bucket
    _write_memory(mem)
    return f"{category}/{key} hafızaya kaydedildi."


def update_memory(data: dict):
    mem = load_memory()
    _deep_merge(mem, data)
    _write_memory(mem)


def delete_memory(category: str = "", key: str = "", match_text: str = "") -> str:
    mem = load_memory()
    if not mem:
        return "Hafızada silinecek bir kayıt yok."

    category = (category or "").strip()
    key = (key or "").strip()
    match_text = (match_text or "").strip()

    if category and key:
        bucket = mem.get(category)
        if isinstance(bucket, dict) and key in bucket:
            del bucket[key]
            if not bucket:
                mem.pop(category, None)
            _write_memory(mem)
            return f"{category}/{key} hafızadan kaldırıldı."
        return "Bu hafıza kaydını bulamadım."

    needle = _normalize_text(match_text or key)
    if not needle:
        return "Silmek için category/key veya match_text gerekli."

    for cat, bucket in list(mem.items()):
        if cat == "_meta":
            continue
        if not isinstance(bucket, dict):
            if _entry_matches(needle, cat, cat, bucket):
                del mem[cat]
                _write_memory(mem)
                return f"{cat} hafızadan kaldırıldı."
            continue

        for item_key, item_value in list(bucket.items()):
            if _entry_matches(needle, cat, item_key, item_value):
                del bucket[item_key]
                if not bucket:
                    mem.pop(cat, None)
                _write_memory(mem)
                return f"{cat}/{item_key} hafızadan kaldırıldı."

    return "Eşleşen bir hafıza kaydı bulamadım."


def _value_to_text(value) -> str:
    if isinstance(value, dict):
        if "value" in value:
            return _entry_value_text(value.get("value"))
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def list_memory(category: str = "", limit: int = 50) -> str:
    mem = load_memory()
    category = (category or "").strip()
    limit = max(1, int(limit or 50))

    lines: list[str] = ["Hafıza özeti:"]
    count = 0
    for cat, bucket in mem.items():
        if cat == "_meta":
            continue
        if category and cat != category:
            continue
        if isinstance(bucket, dict):
            for key, item_value in bucket.items():
                if count >= limit:
                    break
                value = _value_to_text(item_value)
                lines.append(f"- {cat}/{key}: {value}")
                count += 1
        else:
            if count < limit:
                lines.append(f"- {cat}: {bucket}")
                count += 1
        if count >= limit:
            break

    if len(lines) == 1:
        return "Hafızada kayıt bulunamadı."
    return "\n".join(lines)


def search_memory(query: str, category: str = "", limit: int = 10) -> str:
    mem = load_memory()
    query = _normalize_text(query)
    category = (category or "").strip()
    limit = max(1, int(limit or 10))

    if not query:
        return "Arama ifadesi boş olamaz."

    matches: list[str] = []
    for cat, bucket in mem.items():
        if cat == "_meta":
            continue
        if category and cat != category:
            continue
        if isinstance(bucket, dict):
            for key, item_value in bucket.items():
                if _entry_matches(query, cat, key, item_value):
                    value = _value_to_text(item_value)
                    matches.append(f"- {cat}/{key}: {value}")
                    if len(matches) >= limit:
                        break
        else:
            if _entry_matches(query, cat, cat, bucket):
                matches.append(f"- {cat}: {bucket}")
        if len(matches) >= limit:
            break

    if not matches:
        return "Eşleşen hafıza kaydı bulunamadı."
    return "Hafıza eşleşmeleri:\n" + "\n".join(matches)


def format_memory_for_prompt(memory: dict) -> str:
    if not memory:
        return ""
    lines = ["[KULLANICI HAKKINDA HAFIZA]"]
    for category, items in memory.items():
        if category == "_meta":
            continue
        if isinstance(items, dict):
            for key, val in items.items():
                if category == "whatsapp_contacts" and isinstance(val, dict):
                    display_name = val.get("display_name", key)
                    value = val.get("value", "")
                    aliases = val.get("aliases", [])
                    alias_str = ""
                    if isinstance(aliases, list) and aliases:
                        alias_str = f" aliases={', '.join(str(a) for a in aliases)}"
                    lines.append(f"  {category}/{display_name}: {value}{alias_str}")
                elif category in {"calendar_events", "reminders"} and isinstance(val, dict):
                    title = val.get("title", key)
                    when = val.get("start_iso") or val.get("due_iso") or ""
                    lines.append(f"  {category}/{key}: {title} @ {when}")
                else:
                    value = val.get("value", val) if isinstance(val, dict) else val
                    lines.append(f"  {category}/{key}: {value}")
        else:
            lines.append(f"  {category}: {items}")
    return "\n".join(lines)
